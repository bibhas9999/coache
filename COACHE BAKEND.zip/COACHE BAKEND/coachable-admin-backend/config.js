var convict = require('convict');

convict.addFormat(require('convict-format-with-validator').ipaddress);

// Define a schema
var config = convict({
    env: {
        doc: 'The application environment.',
        format: ['production', 'development', 'local'],
        default: 'development',
        env: 'NODE_ENV'
       
    },
    ip: {
        doc: 'The IP address to bind.',
        format: 'ipaddress',
        default: '127.0.0.1',
        env: 'IP_ADDRESS',
    },
    port: {
        doc: 'The port to bind.',
        format: 'port',
        default: 3000,
        env: 'PORT',
        arg: 'port'
    },
    rootUrl: {
        host: "",
        port: "",
        protocol: ""
    },
    db: {
        host: {
            doc: 'Database host name/IP',
            format: '*',
            default: 'mongodb://localhost:3001/'
        },
        name: {
            doc: 'Database name',
            format: String,
            default: 'meteor'
        },
        user: {
            doc: 'Username',
            format: String,
            default: 'root'
        },
        password: {
            doc: 'Database password',
            format: String,
            default: 'root'
        },
        port: {
            doc: 'Database port',
            format: String,
            default: '27017'
        }
    },
    sgMail: {
        apiKey: ''
    },
    nodeMailer: {
        service: "",
        auth: {
            user: "",
            pass: ""
        }
    },
    auth: {
        secret: ""
    },
    reporting: {
        schema: ""
    },
    s3: {
        accessKeyId: "",
        secretAccessKey: "",
        region: "",
        bucket: "",
        folder: ""
    }
});

// Load environment dependent configuration
var env = config.get('env');
config.loadFile('./config/' + env + '.json');

// Perform validation
config.validate({ allowed: 'strict' });

module.exports = config;
