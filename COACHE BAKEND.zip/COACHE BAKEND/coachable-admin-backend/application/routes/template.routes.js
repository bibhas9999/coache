const { authJwt } = require("../middleware");
const msgTemplateController = require("../controllers/msgTemplate.controller");


module.exports = function (app) {
    app.use(function (req, res, next) {
        res.header(
            "Access-Control-Allow-Headers",
            "x-access-token, Origin, Content-Type, Accept"
        );
        next();
    });

    app.get(
        "/api/v1/template/list",
        [authJwt.verifyToken, msgTemplateController.msgTemplateList],
    );
    app.post(
        "/api/v1/template/add",
        [authJwt.verifyToken, msgTemplateController.addMsgTemplate],
    );

};
