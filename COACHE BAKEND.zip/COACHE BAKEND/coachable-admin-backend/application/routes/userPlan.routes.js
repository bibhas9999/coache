const { authJwt } = require("../middleware");
const userPlanController = require("../controllers/userPlan.controller");


module.exports = function (app) {
    app.use(function (req, res, next) {
        res.header(
            "Access-Control-Allow-Headers",
            "x-access-token, Origin, Content-Type, Accept"
        );
        next();
    });

    app.get(
        "/api/v1/userplans",
        [authJwt.verifyToken, userPlanController.UserPlanList],
    );
    app.post(
        "/api/v1/userplans/add",
        [authJwt.verifyToken, userPlanController.addUserPlan],
    );
    app.get(
        "/api/v1/userplans/:userplanId",
        [authJwt.verifyToken, userPlanController.getParticularUserPlan],
    );

};
