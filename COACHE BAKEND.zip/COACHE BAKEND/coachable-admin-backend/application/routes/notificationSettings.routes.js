const { authJwt } = require("../middleware");
const notificationController = require("../controllers/notification.controller");



module.exports = function (app) {
    app.use(function (req, res, next) {
        res.header(
            "Access-Control-Allow-Headers",
            "x-access-token, Origin, Content-Type, Accept"
        );
        next();
    });


    app.get(
        "/api/v1/notificationSettings/coach",
        [authJwt.verifyToken, notificationController.coachNotificationSettings],
    );
    app.patch(
        "/api/v1/notificationSettings/coach/:id",
        [authJwt.verifyToken, notificationController.updateCoachSettings],
    );
    app.get(
        "/api/v1/notificationSettings/athlete",
        [authJwt.verifyToken, notificationController.athleteNotificationSettings],
    );
    app.patch(
        "/api/v1/notificationSettings/athlete/:id",
        [authJwt.verifyToken, notificationController.updateAthleteSettings],
    );

};
