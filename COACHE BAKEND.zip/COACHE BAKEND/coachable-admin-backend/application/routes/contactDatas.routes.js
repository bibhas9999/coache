const { authJwt } = require("../middleware");
const contactController = require("../controllers/contact.controller");



module.exports = function (app) {
    app.use(function (req, res, next) {
        res.header(
            "Access-Control-Allow-Headers",
            "x-access-token, Origin, Content-Type, Accept"
        );
        next();
    });


    app.get(
        "/api/v1/contactDatas",
        [authJwt.verifyToken, contactController.contactDatas],
    );
    app.get(
        "/api/v1/contactDatas/:userId",
        [authJwt.verifyToken, contactController.getContactDatasById],
    );

    // app.patch(
    //     "/api/v1/paymentSettings/:id",
    //     [authJwt.verifyToken, paymentController.updatePaymentSettings],
    // );

};
