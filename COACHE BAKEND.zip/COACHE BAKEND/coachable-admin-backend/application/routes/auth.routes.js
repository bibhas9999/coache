const { authJwt } = require("../middleware");
const controller = require("../controllers/auth.controller");

module.exports = function (app) {
    app.use(function (req, res, next) {
        res.header("Access-Control-Allow-Origin", "*");
        res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
        next();
    });

    app.post("/api/v1/signin", controller.signin);
    app.post("/api/v1/signout", [authJwt.verifyToken, controller.signout]);
    app.get("/api/v1/refresh_token", [authJwt.verifyToken, controller.refreshToken]);
   
};