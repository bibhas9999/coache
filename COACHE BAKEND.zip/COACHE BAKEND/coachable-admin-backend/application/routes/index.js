module.exports = function (app) {

    require('./auth.routes')(app);
    require('./admin.routes')(app);
    require('./userPlan.routes')(app);
    require('./paymentSettings.routes')(app);
    require('./applicationSettings.routes')(app);
    require('./message.routes')(app)
    require('./adminPromotion.routes')(app);
    require('./user.routes')(app);
    require('./notificationSettings.routes')(app);
    require('./contactDatas.routes')(app);
    require('./report.routes')(app);
    require('./template.routes')(app);

}

