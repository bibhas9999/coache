const { authJwt } = require("../middleware");
const userController = require("../controllers/user.controller");
const roleController = require("../controllers/role.controller");
const upload = require("../middleware/upload");
const uploads = require("../middleware/uploadCsvFile");



module.exports = function (app) {
    app.use(function (req, res, next) {
        res.header(
            "Access-Control-Allow-Headers",
            "x-access-token, Origin, Content-Type, Accept"
        );
        next();
    });


    app.get(
        "/api/v1/users",
        [authJwt.verifyToken, userController.usersList],
    );
    app.get(
        "/api/v1/users/:userId",
        [authJwt.verifyToken, userController.getUserById],
    );
    app.patch(
        "/api/v1/users/:user",
        [authJwt.verifyToken, userController.updateUser],
    );
    app.get(
        "/api/v1/roles",
        [authJwt.verifyToken, roleController.UserListByRole],
    );
    app.post(
        "/api/v1/upload/:userId",
        [authJwt.verifyToken, upload.single('avatar'), userController.uploadFile],
    );
    app.post(
        "/api/v1/users/add",
        [authJwt.verifyToken, userController.addUser],
    );
    app.delete(
        "/api/v1/users/delete/:userId",
        [authJwt.verifyToken, userController.deleteUserId],
    );
    app.post(
        "/api/v1/uploads",
        [authJwt.verifyToken, uploads.single('file'), userController.uploadCSVFile],
    );

};
