const validator = require("../library/validations");
const errorHandler = require("../handler/errorHandler");


exports.createAdminPromotionValidations = (payloadData, res) => {
    try {
        let validated = false

        validator.validStringData('NAME', payloadData.name)
        validator.validStringData('COUPON CODE', payloadData.coupon_code)
        validator.validStringData('DESCRIPTION', payloadData.description)
        validator.validPositiveNumber('USAGE LIMIT', payloadData.usage_limit)
        validator.validUserType('USER TYPE', payloadData.userType)
        validator.validPositiveNumber('DISCOUNT TYPE', payloadData.flat_discount)
        validator.validPositiveNumber('DISCOUNT PERCENTAGE', payloadData.discount_percent)
        validator.validPaymentType('DISCOUNT DURATION TYPE', payloadData.duration)
        // validator.validPositiveNumber('DURATION IN MONTH', payloadData.duration_in_months)

        validated = true;

        return validated;

    } catch (error) {
        errorHandler.errorHandler(400, error, res);
        return false
    }
};

