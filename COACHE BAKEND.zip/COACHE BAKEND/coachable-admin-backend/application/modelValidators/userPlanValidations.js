const validator = require("../library/validations");
const errorHandler = require("../handler/errorHandler");

// all required validations for creating a new report for higher education
exports.createUserPlanValidations = (payloadData, res) => {
    try {
        let validated = false
        validator.validBoolean('disabled', payloadData.disabled)
        validator.validPositiveNumber('ONE TIME FEE', payloadData.oneTimeFee)
        validator.validPaymentType('PAYMENT TYPE', payloadData.paymentType)
        validator.validPaymentInterval('PAYMENT INTERVAL', payloadData.paymentInterval)
        validator.validPositiveNumber('PAYMENT AMOUNT', payloadData.paymentAmount)
        validator.validPositiveNumber('ALLOWED STORAGE', payloadData.allowedStorage)
        validator.validStringData('PLAN NAME', payloadData.planName)
        validator.validUserType('USER TYPE', payloadData.userType)
        validator.validStringData('DESCRIPTION', payloadData.description)
        validated = true;
        return validated;
    } catch (error) {
        errorHandler.errorHandler(400, error, res);
        return false
    }
};


// all required validations for creating a new report for K12 organization education
exports.createK12ReportValidations = (payloadData, res) => {
    try {

        let validated = false

        // validator.validNumber('Incident Date', payloadData.incidentDate)
        validator.validNumber('Incident Day', payloadData.incidentDay)
        validator.validStringData('Incident Month', payloadData.incidentMonth)
        validator.validMonth('Incident Month', payloadData.incidentMonth)
        validator.validNumber('Incident Year', payloadData.incidentYear)
        validator.validNumber('Incident Hours', payloadData.incidentHours)
        validator.validNumber('Incident Minutes', payloadData.incidentMinutes)
        validator.validAMPM('AM / PM', payloadData.amPm)
        validator.validStringData('Incident Address', payloadData.incidentAddress)
        validator.validStringData('Incident City', payloadData.incidentCity)
        validator.validStringData('Incident State', payloadData.incidentState)
        validator.validNumber('Incident Zip', payloadData.incidentZip)
        validator.validStringData('Incident Country', payloadData.incidentCountry)

        validator.validBoolean('Happened with you', payloadData.happenedToYou)
        validator.validBoolean('Happened with someone else', payloadData.happenedToElse)
        if (payloadData.happenedToElse) {
            validator.validStringData("Someone Else's Name", payloadData.elsesName)
        }
        validator.validBoolean('Any Suspect', payloadData.anySuspect)
        if (payloadData.anySuspect) {
            validator.validStringData('Suspect Name', payloadData.suspectName)
            validator.validPhoneNumber('Suspect PhoneNumber', payloadData.suspectPhone)
        }
        validator.validNumber('No of Witnesses', payloadData.witnessCount)
        if (payloadData.witnessCount && payloadData.witnessCount > 0) {
            validator.validStringData('Witness1 Name', payloadData.witness1Name)
            validator.validPhoneNumber('Witness1 PhoneNumber', payloadData.witness1Contact)
            if (payloadData.witnessCount > 1) {
                validator.validStringData('Witness2 Name', payloadData.witness2Name)
                validator.validPhoneNumber('Witness2 PhoneNumber', payloadData.witness2Contact)
            }
        }

        validator.validBoolean('Physical Bullying', payloadData.physicalBullying)
        validator.validBoolean('Verbal Bullying', payloadData.verbalBullying)
        validator.validBoolean('Cyber Bullying', payloadData.cyberBullying)
        validator.validBoolean('Other Bullying', payloadData.otherBullying)

        validator.validBoolean('Threat to school', payloadData.threatToSchool)
        validator.validBoolean('Threat to student', payloadData.threatToStudent)
        validator.validBoolean('Threat to teacher', payloadData.threatToTeacher)
        validator.validBoolean('Threat to You', payloadData.threatToYou)
        validator.validBoolean('Threat to others', payloadData.threatToOthers)

        validator.validBoolean('Covid', payloadData.covid)
        validator.validBoolean('Flu', payloadData.flu)
        validator.validBoolean('Fever', payloadData.fever)
        validator.validBoolean('Other health issue', payloadData.otherHealth)

        validator.validBoolean('Unusual Behaviour', payloadData.unusualBehaviour)
        validator.validBoolean('Vehicle driving slowly', payloadData.vehichleDrivingSlowly)
        validator.validBoolean('Leaving of package or Item', payloadData.leavingOfItem)
        validator.validBoolean('Random Activity', payloadData.randomActivity)
        validator.validBoolean('Other Suspicious Activity', payloadData.otherSuspiciousActivity)

        validator.validBoolean('Sexual Comments', payloadData.sexualComments)
        validator.validBoolean('Sexual Advances', payloadData.sexualAdvances)
        validator.validBoolean('Cyber Harrassment', payloadData.cyberHarrassment)
        validator.validBoolean('Sexual Favours', payloadData.sexualFavours)
        validator.validBoolean('Flashing', payloadData.flashing)
        validator.validBoolean('Peeping', payloadData.peeping)
        validator.validBoolean('Stalking', payloadData.stalking)
        validator.validBoolean('Sexual Rumours', payloadData.sexualRumours)
        validator.validBoolean('Gripping/Pulling', payloadData.gripPull)
        validator.validBoolean('Other Sexual Activity', payloadData.otherSexualActivity)

        //mental health related validations
        mentalHealthValidations(payloadData)
        validated = true
        return validated
    } catch (error) {
        throw error
        return false
    }
};

//mental health related validations
const mentalHealthValidations = (payloadData) => {
    try {
        validator.validBoolean('Substance Misuse', payloadData.drugsNASubstanceMisuse)
        validator.validBoolean('Substance Misuse', payloadData.drinkSubstanceMisuse)
        validator.validBoolean('Substance Misuse', payloadData.friendsSubstanceMisuse)
        validator.validBoolean('Substance Misuse', payloadData.concernSubstanceMisuse)
        validator.validBoolean('Substance Misuse', payloadData.relativesSubstanceMisuse)
        validator.validBoolean('Substance Misuse', payloadData.struggleSubstanceMisuse)
        validator.validBoolean('Substance Misuse', payloadData.alcoholSubstanceMisuse)
        validator.validBoolean('Substance Misuse', payloadData.decidedSubstanceMisuse)
        validator.validBoolean('Substance Misuse', payloadData.lifeSubstanceMisuse)
        validator.validBoolean('Substance Misuse', payloadData.upsetSubstanceMisuse)
        validator.validBoolean('Suicide', payloadData.deadwishSuicide)
        validator.validBoolean('Suicide', payloadData.nonSpecificReasonSuicide)
        validator.validBoolean('Suicide', payloadData.nospecificReasonSuicide)
        validator.validBoolean('Suicide', payloadData.specificReasonSuicide)
        validator.validBoolean('Suicide', payloadData.behaviourSuicide)
        validator.validBoolean('Eat Disorder', payloadData.refuseEatDisorder)
        validator.validBoolean('Eat Disorder', payloadData.publicEatDisorder)
        validator.validBoolean('Eat Disorder', payloadData.caloriesEatDisorder)
        validator.validBoolean('Eat Disorder', payloadData.breakingEatDisorder)
        validator.validBoolean('Eat Disorder', payloadData.bodyShapeEatDisorder)
        validator.validBoolean('Eat Disorder', payloadData.vomitEatDisorder)
        validator.validBoolean('Depression', payloadData.sadnessDepression)
        validator.validBoolean('Depression', payloadData.hisroryDepression)
        validator.validBoolean('Depression', payloadData.hopelessDepression)
        validator.validBoolean('Depression', payloadData.suicidalDepression)
        validator.validBoolean('Depression', payloadData.lowEnergyDepression)
        validator.validBoolean('Depression', payloadData.failureDepression)
        validator.validBoolean('Anxiety', payloadData.dailyAnxiety)
        validator.validBoolean('Anxiety', payloadData.concentrationAnxiety)
        validator.validBoolean('Anxiety', payloadData.fearAnxiety)
        validator.validBoolean('Anxiety', payloadData.unsocialAnxiety)
        validator.validBoolean('Anxiety', payloadData.healthAnxiety)
        validator.validBoolean('Anxiety', payloadData.interferingAnxiety)
        return true
    } catch (error) {
        throw error
    }
};


// all required validations for updating a report
exports.updateReportValidations = async (reportId, payloadData, res) => {
    try {
        let validated = false
        validator.validStringData('Report Id', reportId)
        validator.validNumber('Incident Date', payloadData.incidentDate)
        validator.validNumber('Incident Hours', payloadData.incidentHours)
        validator.validNumber('Incident Minutes', payloadData.incidentMinutes)
        validator.validStringData('Incident Address', payloadData.incidentAddress)
        validator.validStringData('Incident City', payloadData.incidentCity)
        validator.validStringData('Incident State', payloadData.incidentState)
        validator.validNumber('Incident Zip', payloadData.incidentZip)
        validator.validStringData('Incident Country', payloadData.incidentCountry)
        validator.validBoolean('Controlled property of Institution', payloadData.onControlPropOfInst)
        validator.validBoolean('Recognised student organization', payloadData.onControlStudentOrg)
        validator.validStringData('Victim FirstName', payloadData.victimFirstName)
        validator.validStringData('Victim LastName', payloadData.victimLastName)
        validator.validPhoneNumber('Victim PhoneNumber', payloadData.victimPhone)
        validator.validEmail('Victim Email', payloadData.victimEmail)
        validator.validBoolean('Any Suspect', payloadData.anySuspect)
        if (payloadData.anySuspect) {
            validator.validStringData('Suspect Name', payloadData.suspectName)
            validator.validPhoneNumber('Suspect PhoneNumber', payloadData.suspectPhone)
        }
        validator.validNumber('No of Witnesses', payloadData.witnessCount)
        if (payloadData.witnessCount && payloadData.witnessCount > 0) {
            validator.validStringData('Witness1 Name', payloadData.witness1Name)
            validator.validPhoneNumber('Witness1 PhoneNumber', payloadData.witness1Contact)
            if (payloadData.witnessCount > 1) {
                validator.validStringData('Witness2 Name', payloadData.witness2Name)
                validator.validPhoneNumber('Witness2 PhoneNumber', payloadData.witness2Contact)
            }
        }
        validator.validBoolean('Negligent Slaughter', payloadData.negligentSlaughter)
        validator.validBoolean('Non Negligent Slaughter', payloadData.nonNegligentSlaughter)
        // sexual offence
        validator.validBoolean('Rape', payloadData.rape)
        validator.validBoolean('Pending', payloadData.pending)
        validator.validBoolean('Incest', payloadData.incest)
        validator.validBoolean('Statutory Rape', payloadData.sRape)
        validator.validBoolean('Robbery', payloadData.robbery)
        validator.validBoolean('Aggressive Assault', payloadData.aggrAssault)
        validator.validBoolean('Burglary', payloadData.burglary)
        validator.validBoolean('Arson', payloadData.arson)
        validator.validBoolean('Motor Theft', payloadData.motorTheft)
        // arrest related
        validator.validBoolean('Weapons Law Violation', payloadData.wLawViolate)
        validator.validBoolean('Drug Abuse Violation', payloadData.dAbuseViolate)
        validator.validBoolean('Liquor Law Violation', payloadData.lLawViolate)
        // hate crimes
        validator.validBoolean('Larcency Theft', payloadData.larcencyTheft)
        validator.validBoolean('Simple Assault', payloadData.simpleAssault)
        validator.validBoolean('Intimidation', payloadData.intimidation)
        validator.validBoolean('Destruction Damage', payloadData.desDamage)
        // bias category
        validator.validBoolean('Race', payloadData.race)
        validator.validBoolean('Gender', payloadData.gender)
        validator.validBoolean('Religion', payloadData.religion)
        validator.validBoolean('National Origin', payloadData.natOrigin)
        validator.validBoolean('Sexual Orientation', payloadData.sexOrientation)
        validator.validBoolean('Gender Identity', payloadData.genderIdentity)
        validator.validBoolean('Ethnicity', payloadData.ethnicity)
        validator.validBoolean('Disability', payloadData.disability)
        // clery sexual violence
        validator.validBoolean('Domestic Violence', payloadData.domViolence)
        validator.validBoolean('Dating Violence', payloadData.datingViolence)
        validator.validBoolean('Stalking', payloadData.stalking)

        if (typeof payloadData.threat !== 'undefined' || typeof payloadData.healthRisk !== 'undefined') {
            validator.validStringData('Note', payloadData.note)
        }
        //
        validated = true
        return validated
    } catch (error) {
        errorHandler.errorHandler(400, error, res);
        return false
    }
};