const applicationService = require("../services/applicationService");


exports.applicationSettings= (req, res) => {
    
    try {
        applicationService.getApplicationSettingsList(req.username, res)
    } catch (error) {
        console.log(error, 'error')
    }
};


exports.updateApplicationSettings = (req, res) => {
    try {
        const applicationId = req.params['id'];


        // const updateData = {
        //     firstTierReferrerPercentage: req.body.firstTierReferrerPercentage,
        //     // firstName: req.body.firstName,
        //     // lastName: req.body.lastName,
        //     // email: req.body.email,
        //     // role: req.body.role,
        //     updatedAt: new Date().getTime()
        // }


        const updateData = {};


        if (req.body.aboutUs) {
            updateData.aboutUs= req.body.aboutUs
        }
        if (req.body.privacyPolicy) {
            updateData.privacyPolicy= req.body.privacyPolicy
        }
        if (req.body.frequentlyAskedQuestions) {
            updateData.frequentlyAskedQuestions= req.body.frequentlyAskedQuestions
        }
        if (req.body.termsAndConditions) {
            updateData.termsAndConditions= req.body.termsAndConditions
        }
        if (req.body.introductoryVideo) {
            updateData.introductoryVideo= req.body.introductoryVideo
        }
        if (req.body.additionalCreditGainPercentageOnWebSignup) {
            updateData.additionalCreditGainPercentageOnWebSignup= req.body.additionalCreditGainPercentageOnWebSignup
        }

        // const validated = userValidation.updateUserValidations(paymentId, updateData, res);
        // if (validated)
        applicationService.updateUser(req.username, applicationId, updateData, res)
    } catch (error) {
        console.log(error, 'error')
    }
};