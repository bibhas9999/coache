
const userValidation = require("../services/userValidations");
const userService = require("../services/userService");
const errorHandler = require("../handler/errorHandler");

// being used in Cochable
exports.signin = (req, res) => {
    try {

        const loginDetails = {
            password: req.body.password,
            username: req.body.username
          
        };
        // add validations for fields
        const validated = userValidation.loginValidations(loginDetails,res)

        // call login
        if (validated)
            userService.verifyUser(loginDetails, res)
    } catch (error) {
        console.log(error, 'error in signin')
        throw error
    }
};

// being used in coachable
exports.signout = (req, res) => {
    try {
        // logout user
        userService.signout(req.username, res)
    } catch (error) {
        errorHandler.errorHandler(400, error, res)
    }
};


exports.refreshToken = (req, res) => {
    try {
        // get updated token for the user
        userService.getRefreshToken(req.username, res)
    } catch (error) {
        errorHandler.errorHandler(400, error, res)
    }
};
