const contactService = require("../services/contactService");


exports.contactDatas = (req, res) => {

    try {
        contactService.getContactDatas(req.username, res)
    } catch (error) {
        console.log(error, 'error')
    }
};
exports.getContactDatasById = (req, res) => {
    try {
        const filter = {
            id: req.params['userId'],
        }

        // const validated = userValidation.requiredDataValidation('User Id', filter.id, res);
        // if (validated)
        contactService.getContactDatasById(req.username, filter, res)
    } catch (error) {
        console.log(error, 'error')
    }
};



// exports.updatecontactSettings = (req, res) => {
//     try {
//         const contactId = req.params['id'];


//         // const updateData = {
//         //     firstTierReferrerPercentage: req.body.firstTierReferrerPercentage,
//         //     // firstName: req.body.firstName,
//         //     // lastName: req.body.lastName,
//         //     // email: req.body.email,
//         //     // role: req.body.role,
//         //     updatedAt: new Date().getTime()
//         // }


//         const updateData = {};


//         if (req.body.applicationFeePercentage) {
//             updateData.applicationFeePercentage = req.body.applicationFeePercentage
//         }
//         if (req.body.firstTierReferrerPercentage) {
//             updateData.firstTierReferrerPercentage = req.body.firstTierReferrerPercentage
//         }
//         if (req.body.secondTierReferrerPercentage) {
//             updateData.secondTierReferrerPercentage = req.body.secondTierReferrerPercentage
//         }
//         if (req.body.thirdTierReferrerPercentage) {
//             updateData.thirdTierReferrerPercentage = req.body.thirdTierReferrerPercentage
//         }
//         if (req.body.userRole) {
//             updateData.userRole = req.body.userRole
//         }

//         // const validated = userValidation.updateUserValidations(contactId, updateData, res);
//         // if (validated)
//         contactService.updateUser(req.username, contactId, updateData, res)
//     } catch (error) {
//         console.log(error, 'error')
//     }
// };