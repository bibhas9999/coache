const userPlanService = require("../services/userPlanService");
const userValidations =require("../services/userValidations")


exports.UserPlanList= (req, res) => {
    
    try {
        userPlanService.getUserPlanList(req.username, res)
    } catch (error) {
        console.log(error, 'error')
    }
};

exports.addUserPlan= async (req, res) => {
   
    try {
        let payloadData = {
           
            disabled: req.body.disabled,
            oneTimeFee: req.body.oneTimeFee,
            paymentType: req.body.paymentType,
            paymentInterval: req.body.paymentInterval,
            paymentAmount: req.body.paymentAmount,
            allowedStorage: req.body.allowedStorage,
            planName: req.body.planName,
            userType: req.body.userType,
            description: req.body.description,
        }

        
       
     await userPlanService.createUserPlan(req.username, payloadData, res);
      
    } catch (error) {
        console.log(error, 'error')
    }
};

exports.getParticularUserPlan = (req, res) => {
   
    try {
        // const filter = {
        //     userplanId: req.params.userplanId ? req.params.userplanId : false
        // }
        const filter = {
            // _id: req.params['userplanId']
            _id: req.params.userplanId
        }

       const validated = userValidations.requiredDataValidation('userPlanId', filter._id, res);
        if (validated)
        userPlanService.getParticularUserPlan(req.username, filter, res);
  
    } catch (error) {
        console.log(error, 'error')
    }
};