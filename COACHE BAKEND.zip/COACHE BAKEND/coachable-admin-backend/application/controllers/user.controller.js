const userService = require("../services/userService");
const userValidation = require("../services/userValidations");
const bodyParser = require("body-parser");

// used in csa
exports.usersList = (req, res) => {
    try {
        let filter = {};

        if (req.query.role) {
            filter['roles.0'] = req.query.role;
        }
        if (req.query.email) {
            filter['emails.0.address'] = req.query.email;
        }
        if (req.query.username) {
            filter.username = req.query.username;
        }
        // if (req.query.page) {
        //     filter.page = req.query.page;
        // }
        const page = req.query.page;
        const details = {
            role: req.query.role,
            email: req.query.email,
            username: req.query.username,
        }

        const validated = userValidation.UserValidations(details, res)

        // call data
        if (validated)
            userService.getUsersList(req.username, page, filter, res)
    } catch (error) {
        console.log(error, 'Error in data Fetch')
        throw error
    }
};


//     try {
//         const filter = {
//             role: req.query.role,
//             email: req.query.email,
//             username: req.query.username,
//         }
//         userService.getUsersList(req.username, res, filter)
//     } catch (error) {
//         console.log(error, 'error')
//     }
// }; 
//get api in node.js with search,filter,sort & pagination


exports.addUser = async (req, res) => {

    try {
        let payloadData = {

            profile: {

                lastName: req.body.profile.lastName,
                firstName: req.body.profile.firstName
            },
            emails: [
                {

                    address: req.body.emails.address
                },

            ],
            username: req.body.username,
            roles: req.body.roles,


            allowedStorage: req.body.allowedStorage,
            packagePurchased: req.body.packagePurchased

        }

        console.log("payloadData", payloadData)

        const filter = {
            firstName: req.body.firstName,
            lastName: req.body.lastName,
            email: req.body.email,
            username: req.body.username,
            role: req.body.role,
            allowedStorage: req.body.allowedStorage,
            packagePurchased: req.body.packagePurchased

        }

        console.log(payloadData)
        // add validations for fields
        // const validated = await userValidation.userValidations(payloadData, res)
        // call insert to database
        // if (validated)
        userService.insertUser(req.username, payloadData, res)

    } catch (error) {
        console.log(error, 'error in signup')
        throw error
    }

};
exports.getUserById = (req, res) => {
    try {
        const filter = {
            id: req.params['userId'],
        }

        // const validated = userValidation.requiredDataValidation('User Id', filter.id, res);
        // if (validated)
        userService.getUserById(req.username, filter, res)
    } catch (error) {
        console.log(error, 'error')
    }
};

exports.updateUser = (req, res) => {
    try {
        const userId = req.params['user'];


        // const updateData = {
        //     firstTierReferrerPercentage: req.body.firstTierReferrerPercentage,
        //     // firstName: req.body.firstName,
        //     // lastName: req.body.lastName,
        //     // email: req.body.email,
        //     // role: req.body.role,
        //     updatedAt: new Date().getTime()
        // }


        const updateData = {};


        if (req.body.firstName) {
            updateData['profile.firstName'] = req.body.firstName,
                updateData['updatedAt'] = new Date().getTime()
        }
        if (req.body.lastName) {
            updateData['profile.lastName'] = req.body.lastName,
                updateData['updatedAt'] = new Date().getTime()
        }
        // if (req.body.email) {
        //     updateData['emails.0.address'] = req.body.email,
        //         updateData['updatedAt'] = new Date().getTime()
        // }
        if (req.body.role) {
            updateData['roles.0'] = req.body.role,
                updateData['updatedAt'] = new Date().getTime()
        }

        // const validated = userValidation.updateUserValidations(userId, updateData, res);
        // if (validated)
        userService.updateUser(req.username, userId, updateData, res)
    } catch (error) {
        console.log(error, 'error')
    }
};

exports.uploadFile = (req, res) => {


    try {
        const userId = req.params['userId'];
        const uploadData = {};


        if (req.file.path) {
            uploadData['avatar'] = req.file.path
        }
        userService.getFileUpload(req.username, userId, uploadData, res)
    } catch (error) {
        console.log(error, 'error')
    }
};
exports.uploadCSVFile = (req, res) => {


    try {

        const uploadData = [];
        // if (req.file.path) {
        //     uploadData['file'] = req.file.path

        // }
        if (req.file.path) {
            uploadData.path = req.file.path

        }
        if (req.file.originalname) {
            uploadData.name = req.file.originalname

        }

        userService.getCsvFileUpload(req.username, req, uploadData, res)
    } catch (error) {
        console.log(error, 'error')
    }
};

exports.getProfile = (req, res) => {
    try {
        userService.getProfile(req.username, res)
    } catch (error) {
        console.log(error, 'error')
    }
};
exports.getUserData = (req, res) => {
    try {
        userService.getUserData(req.username, res)
    } catch (error) {
        console.log(error, 'error')
    }
};

exports.deleteUserId = (req, res) => {
    try {
        const filter = {
            id: req.params['userId'],
        }

        // const validated = userValidation.requiredDataValidation('User Id', filter.id, res);
        // if (validated)
        userService.deleteUserId(req.username, filter, res)
    } catch (error) {
        console.log(error, 'error')
    }
};



