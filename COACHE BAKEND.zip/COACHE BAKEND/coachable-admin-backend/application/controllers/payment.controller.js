const paymentService = require("../services/paymentService");


exports.paymentSettings = (req, res) => {

    try {
        paymentService.getPaymentSettingsList(req.username, res)
    } catch (error) {
        console.log(error, 'error')
    }
};


exports.updatePaymentSettings = (req, res) => {
    try {
        const paymentId = req.params['id'];


        // const updateData = {
        //     firstTierReferrerPercentage: req.body.firstTierReferrerPercentage,
        //     // firstName: req.body.firstName,
        //     // lastName: req.body.lastName,
        //     // email: req.body.email,
        //     // role: req.body.role,
        //     updatedAt: new Date().getTime()
        // }


        const updateData = {};


        if (req.body.applicationFeePercentage) {
            updateData.applicationFeePercentage = req.body.applicationFeePercentage
        }
        if (req.body.firstTierReferrerPercentage) {
            updateData.firstTierReferrerPercentage = req.body.firstTierReferrerPercentage
        }
        if (req.body.secondTierReferrerPercentage) {
            updateData.secondTierReferrerPercentage = req.body.secondTierReferrerPercentage
        }
        if (req.body.thirdTierReferrerPercentage) {
            updateData.thirdTierReferrerPercentage = req.body.thirdTierReferrerPercentage
        }
        if (req.body.userRole) {
            updateData.userRole = req.body.userRole
        }

        // const validated = userValidation.updateUserValidations(paymentId, updateData, res);
        // if (validated)
        paymentService.updateUser(req.username, paymentId, updateData, res)
    } catch (error) {
        console.log(error, 'error')
    }
};