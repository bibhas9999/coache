const messageService = require("../services/messageService");
const userValidation = require("../services/userValidations");

// used in coachable
exports.messageList = (req, res) => {
    try {
        let userId = {};
        if (req.query.athleteId) {
            userId.athleteId = req.query.athleteId;
        }
        if (req.query.coachId) {
            userId.coachId = req.query.coachId;
        }

        const details = {
            coachId: req.query.coachId,
            athleteId: req.query.athleteId
        }
        console.log()

        const validated = userValidation.UserIdValidations(details, res)

        // call data
        if (validated)
            messageService.getMessageList(req.username, res, userId)
    } catch (error) {
        console.log(error, 'Error in data Fetch')
        throw error
    }
};

exports.conversationList = (req, res) => {

    try {
        let filter = {};
        if (req.query.athleteName) {
            filter.athleteName = req.query.athleteName;
        }
        if (req.query.coachName) {
            filter.coachName = req.query.coachName;
        }

        const details = {
            coachName: req.query.coachName,
            athleteName: req.query.athleteName
        }
        const validated = userValidation.UserNameValidations(details, res)

        // call data
        if (validated)
            messageService.getconversationList(req.username, res, filter)
    } catch (error) {
        console.log(error, 'Error in data Fetch')
    }
};
exports.getConversationListById = (req, res) => {
    try {
        let data = {
            id: req.params['chatId'],
        }



        // const validated = userValidation.requiredDataValidation('User Id', filter.id, res);
        // if (validated)
        messageService.getConversationListById(req.username, data, res)
    } catch (error) {
        console.log(error, 'error')
    }
};