const reportService = require("../services/reportService");



exports.reportList = (req, res) => {

    try {
        reportService.getReportList(req.username, res)
    } catch (error) {
        console.log(error, 'error')
    }
};

