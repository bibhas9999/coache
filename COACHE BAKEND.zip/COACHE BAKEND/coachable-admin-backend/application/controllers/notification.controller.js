const notificationService = require("../services/notificationService");


exports.coachNotificationSettings = (req, res) => {

    try {
        notificationService.getCoachNotificationSettings(req.username, res)
    } catch (error) {
        console.log(error, 'error')
    }
};
exports.athleteNotificationSettings = (req, res) => {

    try {
        notificationService.getAthleteNotificationSettings(req.username, res)
    } catch (error) {
        console.log(error, 'error')
    }
};


exports.updateCoachSettings = (req, res) => {
    try {
        const coachId = req.params['id'];


        const updateData = {
            newMessages: req.body.newMessages,
            newSubscriptionSold: req.body.newSubscriptionSold,
            newPackageSold: req.body.newPackageSold,
            newVideoSubmitted: req.body.newVideoSubmitted
        }


        // const updateData = {};


        // if (req.body.newMessages) {
        //     updateData.newMessages = req.body.newMessages
        // }
        // if (req.body.newSubscriptionSold) {
        //     updateData.newSubscriptionSold = req.body.newSubscriptionSold
        // }
        // if (req.body.newPackageSold) {
        //     updateData.newPackageSold = req.body.newPackageSold
        // }
        // if (req.body.newVideoSubmitted) {
        //     updateData.newVideoSubmitted = req.body.newVideoSubmitted
        // }
        // console.log("controller", res.body)

        // const validated = userValidation.updateUserValidations(coachId, updateData, res);
        // if (validated)
        notificationService.updateCoachSettings(req.username, coachId, updateData, res)
    } catch (error) {
        console.log(error, 'error')
    }
};

exports.updateAthleteSettings = (req, res) => {
    try {
        const athleteId = req.params['id'];


        const updateData = {
            newMessages: req.body.newMessages,
            critiqueReceived: req.body.critiqueReceived,
            packageSubscriptionCreated: req.body.packageSubscriptionCreated,
            promotionalMessages: req.body.promotionalMessages
        }


        // const updateData = {};


        // if (req.body.newMessages) {
        //     updateData.newMessages = req.body.newMessages
        // }
        // if (req.body.critiqueReceived) {
        //     updateData.critiqueReceived = req.body.critiqueReceived
        // }
        // if (req.body.packageSubscriptionCreated) {
        //     updateData.packageSubscriptionCreated = req.body.packageSubscriptionCreated
        // }
        // if (req.body.promotionalMessages) {
        //     updateData.promotionalMessages = req.body.promotionalMessages
        // }


        // const validated = userValidation.updateUserValidations(athleteId, updateData, res);
        // if (validated)
        notificationService.updateAthleteSettings(req.username, athleteId, updateData, res)
    } catch (error) {
        console.log(error, 'error')
    }
};