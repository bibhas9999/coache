const msgTemplateService = require("../services/msgTemplateService");
const msgTemplateValidations = require("../modelValidators/msgTemplateValidations")


exports.msgTemplateList = (req, res) => {

    try {
        msgTemplateService.getMsgTemplateList(req.username, res)
    } catch (error) {
        console.log(error, 'error')
    }
};

exports.addMsgTemplate = async (req, res) => {

    try {
        let payloadData = {

            templateName: req.body.templateName,
            message: req.body.message
        }



        await msgTemplateService.createMsgTemplate(req.username, payloadData, res);

    } catch (error) {
        console.log(error, 'error')
    }
};