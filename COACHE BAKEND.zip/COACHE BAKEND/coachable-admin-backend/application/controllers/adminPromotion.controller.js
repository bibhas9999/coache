const adminPromotionService = require("../services/adminPromotionService");
const userValidations = require("../services/userValidations")


exports.promotionalCouponList = (req, res) => {

    try {
        adminPromotionService.getPromotionalCouponList(req.username, res)
    } catch (error) {
        console.log(error, 'error')
    }
};

exports.addPromotionalCoupon = async (req, res) => {

    try {
        let payloadData = {

            name: req.body.name,
            coupon_code: req.body.coupon_code,
            description: req.body.description,
            starts_at: req.body.starts_at,
            expires_at: req.body.expires_at,
            usage_limit: req.body.usage_limit,
            userType: req.body.userType,
            flat_discount: req.body.flat_discount,
            discount_percent: req.body.discount_percent,
            duration: req.body.duration

        }
        console.log(payloadData)



        await adminPromotionService.createAdminPromotion(req.username, payloadData, res);

    } catch (error) {
        console.log(error, 'error')
    }
};

