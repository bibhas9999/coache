const roleService = require("../services/roleService");



exports.UserListByRole = (req, res) => {
    try {
        roleService.getUserRole(req.username, res)
    } catch (error) {
        console.log(error, 'error')
    }
};