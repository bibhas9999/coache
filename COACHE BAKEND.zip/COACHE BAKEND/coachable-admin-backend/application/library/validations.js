const errorHandler = require("../handler/errorHandler");
const validStringData = (name, data) => {
    if (!data || data == null || data == "") {
        throw `${name} is required. Please enter a valid ${name}`;
    }
};

const requiredData = (name, data) => {
    if (!data || data == null) {
        throw `${name} is required. Please enter a valid ${name}`;
    }
};

const validNumber = (name, data) => {
    if (isNaN(data)) {
        throw `${name} is not a valid Number`;
    }
};
const validName = (name, data) => {
    if (isNaN(data)) {
        throw `${name} is not a valid Username`;
    }
};

const validMemberStatus = (name, data) => {
    // 2: active, 3: inactive, 4: unknown, 5: draft
    if (data != 2 && data != 3 && data != 4 && data != 5) {
        throw `${name} is not a valid.`;
    }
};

const validMonth = (name, data) => {
    const months = ["JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE", "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER"]
    if (!months.includes(data)) {
        throw `${name} is not a valid month.`;
    }
};

const validAMPM = (name, data) => {
    // 2: active, 3: inactive, 4: unknown, 5: draft
    if (data != "AM" && data != "PM" && data != "am" && data != "pm") {
        throw `${name} is not valid. Can be AM or PM`;
    }
};

const notEmpty = (name, data) => {
    if (!data || data == null || data == '' || data.trim() == '') {
        throw `${name} is empty. Please provide a valid ${name}`;
    }
};

const validPhoneNumber = (name, number) => {
    validNumber(name, number)
    // validNumber(name, number)
    const numTenRegex = /^[1]\d{10}$/;
    const numElevenRegex = /^[123456789]\d{9}$/;
    let valid = numTenRegex.test(number) || numElevenRegex.test(number);
    if (!valid) {
        throw `${name} is invalid. Please enter a valid ${name}`;
    }

};
const validUserName = (name, number) => {
    validName(name, number)
    // validNumber(name, number)
    const numTenRegex = /^[1]\d{10}$/;
    const numElevenRegex = /^[123456789]\d{9}$/;
    let valid = numTenRegex.test(number) || numElevenRegex.test(number);
    if (!valid) {
        throw `${name} is invalid. Please enter a valid ${name}`;
    }

};

const validBoolean = (name, data) => {
    if (!typeof data == "boolean") {
        // variable is not boolean
        throw `${name} is invalid. Please enter a valid ${name}`;
    }
};

const validGender = (name, data) => {
    if (data != 'M' && data != 'F') {
        throw `${name} is not a valid gender.`;
    }
};

const validRelation = (name, data) => {
    if (data != 'FATHER' && data != 'HUSBAND') {
        throw `${name} is not a valid relation. Can be either FATHER or HUSBAND`;
    }
};
const validUserType = (name, data) => {
    if (data != 'COACH' && data != 'ATHLETE') {
        throw `${name} is not a valid UserType. Can be either COACH or ATHLETE`;
    }
};
const validPaymentInterval = (name, data) => {
    if (data != 'WEEKLY' && data != 'MONTHLY' && data != 'YEARLY') {
        throw `${name} is not a valid Payment Interval. You can choose either of the three intervals: WEEKLY,MONTHLY,YEARLY`;
    }
};
const validPaymentType = (name, data) => {
    if (data != 'ONCE' && data != 'FOREVER' && data != 'RECURRING') {
        throw `${name} is not a valid Payment Type. You can choose either of the three intervals: ONCE,FOREVER,RECURRING`;
    }
};

const validEmail = (name, email) => {
    validStringData(name, email)
    const emailRegex = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    const valid = emailRegex.test(String(email).toLowerCase());
    if (!valid) {
        throw `${name} is invalid. Please enter a valid ${name}`;
    }
};

const validIfPresentEmail = (name, email) => {
    if (email && email != null) {
        const emailRegex = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        const valid = emailRegex.test(String(email).toLowerCase());
        if (!valid) {
            throw `${name} is invalid. Please enter a valid ${name}`;
        }
    }
};

const validDOB = (name, data) => {
    try {
        const todate = new Date().getTime()
        if (data >= todate) {
            throw `${name} is invalid. Date of birth cannot be greater than current date.`;
        }
    } catch (error) {
        throw error
    }
};
const validPositiveNumber = (name, data) => {
    try {
        if (!(Number(data) >= Number(0))) {
            throw `${name} is invalid.Value should be Positive Number `;
        }
    } catch (error) {
        throw error
    }
};

const validPinCode = async (name, data, res) => {
    try {
        const pinCodeDetails = await generalModel.getPincodeDetails(data, res);
        if ((!pinCodeDetails || pinCodeDetails.length <= 0) && data != "Unknown") {
            throw `${name} is invalid. No such pincode. Please check the code again.`;
        }
        return pinCodeDetails;
    } catch (error) {
        throw error
    }
};

const validUserRole = (name, role) => {
    validStringData(name, role)

    if (!['COACH', 'ATHLETE', 'AGENT'].includes(role)) {
        throw `${name} is invalid. You can choose either of the three roles: COACH, ATHLETE, AGENT`;
    }
    return true
};

const validPaymentFrequency = (name, subscriptionFrequency) => {
    validStringData(name, subscriptionFrequency)
    subscriptionFrequency = subscriptionFrequency.toUpperCase()
    if (!['YEARLY', 'MONTHLY', 'WEEKLY'].includes(subscriptionFrequency)) {
        throw `${name} is invalid. You can choose either of the three frequencies: YEARLY, MONTHLY, WEEKLY`;
    }
    return true
};

const validOrganisationType = (name, organisationType) => {
    validStringData(name, organisationType)
    organisationType = organisationType.toUpperCase()
    if (!['K12', 'TRANSPORTATION', 'HIGHER EDUCATION'].includes(organisationType)) {
        throw `${name} is invalid. You can choose either of the three types: K12, TRANSPORTATION, HIGHER EDUCATION`;
    }
    return true
};

const validPassword = (name, password) => {
    validStringData(name, password)
    const strongPwdRegex = /^(?=.*\d)(?=.*[!@#$%^&*])(?=.*[a-z])(?=.*[A-Z]).{8,}$/;
    if (!strongPwdRegex.test(password)) {
        throw `${name} is invalid. Your password must be atleast 8 characters long, with one upper case,lower case character, one number and a special character.`;
    }
};

const validVerificationCode = (name, data) => {
    try {
        if (isNaN(data) || data.toString().length != 6) {
            throw `${name} is invalid. Please enter a valid ${name}`;
        }
    } catch (error) {
        throw error
    }
};

const validConfirmPassword = (newPwd, confirmPassword) => {
    try {
        if (newPwd != confirmPassword) {
            throw `New password and confirm password do not match. Please try again.`;
        }
    } catch (error) {
        throw error
    }
};

const validArray = (name, data) => {
    try {
        if (!data || !Array.isArray(data) || data.length <= 0) {
            throw `${name} is invalid. Please add some users.`;
        }
    } catch (error) {
        throw error
    }
}

const validators = {
    validVerificationCode,
    validConfirmPassword,
    validPassword,
    validEmail,
    validPhoneNumber,
    validUserName,
    validPinCode,
    validUserRole,
    validStringData,
    validBoolean,
    validNumber,
    validName,
    notEmpty,
    requiredData,
    validMemberStatus,
    validIfPresentEmail,
    validGender,
    validRelation,
    validPaymentFrequency,
    validOrganisationType,
    validDOB,
    validAMPM,
    validMonth,
    validArray,
    validUserType,
    validPaymentInterval,
    validPositiveNumber,
    validPaymentType
};

module.exports = validators;

