const jwt = require("jsonwebtoken");
const config = require('../../config');
const authKey = config.get('auth.secret');
const errorHandler = require("../handler/errorHandler");

verifyToken = (req, res, next) => {
    try {
        let token = req.headers["x-access-token"];
       
        if (!token || token == null || token.trim() == "") {
            errorHandler.errorHandler(403, 'Invalid token. Authentication failed.', res)
            return
        }

        jwt.verify(token, authKey, (err, decoded) => {
            if (err) {
                errorHandler.errorHandler(401, 'Unauthorised.', res)
                return
            }
            // req.email = decoded.id;
            req.username = decoded.id;
            next();
        });
    } catch (error) {
        console.log(error, 'error')
        errorHandler.errorHandler(500, 'Server error occurred', res)
    }
};

const authJwt = {
    verifyToken,
};
module.exports = authJwt;