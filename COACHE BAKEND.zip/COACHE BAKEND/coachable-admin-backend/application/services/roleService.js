const errorHandler = require("../handler/errorHandler");
const successHandler = require("../handler/successHandler");
const userModel = require("../models/userModel");
const models = require("../models");

const getUserRole = async (username, res) => {

    try {

        const userDetails = await userModel.getUserByUsername(username, res);

        if (!userDetails && !userDetails.find({ "profile.admin": true })) {
            errorHandler.errorHandler(403, 'Unauthorised user', res)
            return
        }

        const role = await models.role.find({}, { "name": 1 });

        // const role = await models.role.find({},"name");


        if (!role) {
            errorHandler.errorHandler(400, 'No such Role found. Please check your DataBase', res)
            return
        }


        // closed connection
        // await connectionMethod.closeConnection();
        successHandler.successHandler(200, 'Successfully Role List fetch', res, role)
    } catch (error) {
        console.log(error, 'error')
        errorHandler.errorHandler(500, 'Server error occurred', res)
    }


};



const roleService = {
    getUserRole
};

module.exports = roleService;

