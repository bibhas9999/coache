const errorHandler = require("../handler/errorHandler");
const successHandler = require("../handler/successHandler");
const userModel = require("../models/userModel");
const msgTemplateModel = require("../models/msgTemplateModel");
const models = require("../models");
const msgTemplateValidations = require("../modelValidators/msgTemplateValidations");


const getMsgTemplateList = async (username, res) => {

    try {

        const userDetails = await userModel.getUserByUsername(username, res);


        if (!userDetails && !userDetails.find({ "profile.admin": true })) {
            errorHandler.errorHandler(403, 'Unauthorised user', res)
            return
        }
        const list = await models.msgTemplate.find({}, {});

        // console.log(list)

        if (!list) {
            errorHandler.errorHandler(400, 'No such Message Template Found', res)
            return
        }

        // closed connection
        // await connectionMethod.closeConnection();
        successHandler.successHandler(200, 'Successfully Message Template List fetch', res, list)
    } catch (error) {
        console.log(error, 'error')
        errorHandler.errorHandler(500, 'Server error occurred', res)
    }


};

//Create User Plan

const createMsgTemplate = async (username, payloadData, res) => {

    try {

        const userDetails = await userModel.getUserByUsername(username, res);

        if (!userDetails && !userDetails.find({ "profile.admin": true })) {
            errorHandler.errorHandler(403, 'Unauthorised user', res)
            return
        }
        const validatedMsgTemplate = msgTemplateValidations.createMsgTemplateValidations(payloadData, res)


        if (validatedMsgTemplate) {

            const data = await msgTemplateModel.createMsgTemplateList(payloadData, res);
            console.log(data)
            successHandler.successHandler(200, 'Message Template added successfully', res, data);
        }
    } catch (error) {
        console.log(error, 'error')
        errorHandler.errorHandler(500, 'Server error occurred', res)
    }


};

/*const getParticularUserPlan = async (username, filter, res) => {

    try {

        const userDetails = await userModel.getUserByUsername(username, res);


        if (!userDetails && !userDetails.find({ "profile.admin": true })) {
            errorHandler.errorHandler(403, 'Unauthorised user', res)
            return
        }
        const list = await models.UserPlans.findOne(filter);


        // const role = await models.role.find({},"name");

        if (!list) {
            errorHandler.errorHandler(400, 'No such UserPlan Found', res)
            return
        }

        // closed connection
        // await connectionMethod.closeConnection();
        successHandler.successHandler(200, 'Successfully UserPlan List fetch', res, list)
    } catch (error) {
        console.log(error, 'error')
        errorHandler.errorHandler(500, 'Server error occurred', res)
    }


};*/




const msgTemplateService = {
    getMsgTemplateList,
    createMsgTemplate,
    //getParticularUserPlan
};

module.exports = msgTemplateService;

