const errorHandler = require("../handler/errorHandler");
const successHandler = require("../handler/successHandler");
const userModel = require("../models/userModel");
const messageModel = require("../models/messageModel");
const models = require("../models");


const config = require('../../config');




const getMessageList = async (username, res, userId) => {



    try {

        const userDetails = await userModel.getUserByUsername(username, res);

        if (!userDetails && !userDetails.find({ "profile.admin": true })) {
            errorHandler.errorHandler(403, 'Unauthorised user', res)
            return
        }
        const athleteDetails = await messageModel.getAthleteByAthleteId(userId.athleteId, res);
        const coachDetails = await messageModel.getCoachByCoachId(userId.coachId, res);



        let messageId = (athleteDetails, coachDetails) => {
            for (let i = 0; i < athleteDetails.length; i++) {
                for (let j = 0; j < coachDetails.length; j++) {
                    if (athleteDetails[i]._id == coachDetails[j]._id) {

                        let userId = athleteDetails[i]._id;
                        return userId;

                    }



                }
            }
        }
        const newMessageId = messageId(athleteDetails, coachDetails)

        if (!newMessageId) {

            errorHandler.errorHandler(403, 'User Not Found', res)

            return

        }

        console.log(newMessageId)

        list = await models.message.find({ _id: newMessageId }, "messages");

        // const list = await models.role.find({},{});
        // const role = await models.role.find({},"name");

        if (!list) {
            errorHandler.errorHandler(400, 'No such  Message_Threads list Found', res)
            return
        }

        // closed connection
        // await connectionMethod.closeConnection();
        successHandler.successHandler(200, 'Successfully  Message_Threads List fetch', res, list)
    } catch (error) {
        console.log(error, 'error')
        errorHandler.errorHandler(500, 'Server error occurred', res)
    }


};

const getconversationList = async (username, res, filter) => {

    try {

        const userDetails = await userModel.getUserByUsername(username, res);


        if (!userDetails && !userDetails.find({ "profile.admin": true })) {
            errorHandler.errorHandler(403, 'Unauthorised user', res)
            return
        }




        const messageNameList = await models.message.aggregate([
            {
                $lookup: {
                    from: "users",
                    localField: "athleteId",
                    foreignField: "_id",
                    as: "athleteData"
                }

            },
            { $project: { "athleteData.profile.firstName": 1, "athleteData.profile.lastName": 1, coachId: 1, messages: 1 } },
            { $unwind: "$athleteData" },
            { $project: { athleteName: { $concat: ["$athleteData.profile.firstName", " ", "$athleteData.profile.lastName"] }, messages: 1, coachId: 1 } },
            {
                $lookup: {
                    from: "users",
                    localField: "coachId",
                    foreignField: "_id",
                    as: "coachData"
                }

            },
            { $project: { "coachData.profile.firstName": 1, "coachData.profile.lastName": 1, messages: 1, athleteName: 1 } },
            { $unwind: "$coachData" },
            { $project: { coachName: { $concat: ["$coachData.profile.firstName", " ", "$coachData.profile.lastName"] }, messages: 1, athleteName: 1 } },
        ]);







        // const searchQuery = 'example.com'; // Search query to find matching emails

        const filteredUsers = messageNameList.filter(user => user.coachName == filter.coachName || user.coachName == filter.athleteName);



        console.log(filteredUsers);





        if (!filteredUsers) {
            errorHandler.errorHandler(400, 'No such Chat List Found', res)
            return
        }

        if (filter.coachName || filter.athleteName) {
            successHandler.successHandler(200, 'Successfully Chat List fetch', res, filteredUsers)
        } else {
            successHandler.successHandler(200, 'Successfully Chat List fetch', res, messageNameList)
        }


    } catch (error) {
        console.log(error, 'error')
        errorHandler.errorHandler(500, 'Server error occurred', res)
    }


};
// const getConversationListById = async (username, data, res) => {

//     try {

//         const userDetails = await userModel.getUserByUsername(username, res);

//         if (!userDetails && !userDetails.find({ "profile.admin": true })) {
//             errorHandler.errorHandler(403, 'Unauthorised user', res)
//             return
//         }

//         let chatList = []

//         chatList = await messageModel.getChatListById(data.id, res);


//         if (!chatList) {
//             errorHandler.errorHandler(400, 'No such Chat List Found', res)
//             return
//         }

//         successHandler.successHandler(200, 'Successfully Chat List fetch', res, chatList)

//     } catch (error) {
//         console.log(error, 'error')
//         errorHandler.errorHandler(500, 'Server error occurred', res)
//     }


// };

const getConversationListById = async (username, data, res) => {

    try {

        const userDetails = await userModel.getUserByUsername(username, res);

        if (!userDetails && !userDetails.find({ "profile.admin": true })) {
            errorHandler.errorHandler(403, 'Unauthorised user', res)
            return
        }



        const messageNameList = await models.message.aggregate([
            {
                $lookup: {
                    from: "users",
                    localField: "athleteId",
                    foreignField: "_id",
                    as: "athleteData"
                }

            },
            { $project: { "athleteData.profile.firstName": 1, "athleteData.profile.lastName": 1, coachId: 1, messages: 1 } },
            { $unwind: "$athleteData" },
            { $project: { athleteName: { $concat: ["$athleteData.profile.firstName", " ", "$athleteData.profile.lastName"] }, messages: 1, coachId: 1 } },
            {
                $lookup: {
                    from: "users",
                    localField: "coachId",
                    foreignField: "_id",
                    as: "coachData"
                }

            },
            { $project: { "coachData.profile.firstName": 1, "coachData.profile.lastName": 1, messages: 1, athleteName: 1 } },
            { $unwind: "$coachData" },
            { $project: { coachName: { $concat: ["$coachData.profile.firstName", " ", "$coachData.profile.lastName"] }, messages: 1, athleteName: 1 } },
        ]);

        const chatList = messageNameList.filter(user => user._id == data.id);



        console.log(chatList);



        if (!chatList) {
            errorHandler.errorHandler(400, 'No such Chat List Found', res)
            return
        }

        successHandler.successHandler(200, 'Successfully Chat List fetch', res, chatList)

    } catch (error) {
        console.log(error, 'error')
        errorHandler.errorHandler(500, 'Server error occurred', res)
    }


};



const messageService = {
    getMessageList,
    getconversationList,
    getConversationListById

};

module.exports = messageService;

