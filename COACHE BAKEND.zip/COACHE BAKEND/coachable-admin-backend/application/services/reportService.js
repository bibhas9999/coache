const errorHandler = require("../handler/errorHandler");
const successHandler = require("../handler/successHandler");
const userModel = require("../models/userModel");
const reportModel = require("../models/reportModel");
const models = require("../models");



const getReportList = async (username, res) => {

    try {

        const userDetails = await userModel.getUserByUsername(username, res);


        if (!userDetails && !userDetails.find({ "profile.admin": true })) {
            errorHandler.errorHandler(403, 'Unauthorised user', res)
            return
        }




        const reportList = await models.report.aggregate([
            {
                $lookup: {
                    from: "users",
                    localField: "athleteId",
                    foreignField: "_id",
                    as: "athleteData"
                }

            },
            { $project: { "athleteData.profile.firstName": 1, "athleteData.profile.lastName": 1, coachId: 1, title: 1, details: 1, whoReported: 1, reportStatus: 1 } },
            { $unwind: "$athleteData" },
            { $project: { athleteName: { $concat: ["$athleteData.profile.firstName", " ", "$athleteData.profile.lastName"] }, coachId: 1, title: 1, details: 1, whoReported: 1, reportStatus: 1 } },
            {
                $lookup: {
                    from: "users",
                    localField: "coachId",
                    foreignField: "_id",
                    as: "coachData"
                }

            },
            { $project: { "coachData.profile.firstName": 1, "coachData.profile.lastName": 1, title: 1, details: 1, whoReported: 1, reportStatus: 1, athleteName: 1 } },
            { $unwind: "$coachData" },
            { $project: { coachName: { $concat: ["$coachData.profile.firstName", " ", "$coachData.profile.lastName"] }, title: 1, details: 1, whoReported: 1, reportStatus: 1, athleteName: 1 } },
        ]);



        if (!reportList) {
            errorHandler.errorHandler(400, 'No such Report List Found', res)
            return
        }

        successHandler.successHandler(200, 'Successfully Report List fetch', res, reportList)

    } catch (error) {
        console.log(error, 'error')
        errorHandler.errorHandler(500, 'Server error occurred', res)
    }



};






const reportService = {
    getReportList

};

module.exports = reportService;

