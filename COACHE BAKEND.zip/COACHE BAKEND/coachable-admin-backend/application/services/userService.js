const errorHandler = require("../handler/errorHandler");
const successHandler = require("../handler/successHandler");
const userModel = require("../models/userModel");
const passwordModel = require("../models/passwordModel");
const models = require("../models");
const NodeCache = require("node-cache");
const connectionMethod = require("../../config/db.connection");
const jwt = require("jsonwebtoken");
const config = require('../../config');
const authKey = config.get('auth.secret');
const csv = require('csv-parser');
const Email = require('../models/csvFile.js');
const fs = require('fs');
const nodemailer = require('nodemailer');

// being used in COACH
const getUsersList = async (username, page, filter, res) => {


    try {
        let usersList = []
        const userDetails = await userModel.getUserByUsername(username, res);

        if (!userDetails && !userDetails.find({ "profile.admin": true })) {
            errorHandler.errorHandler(403, 'Unauthorised user', res)
            return
        }

        // const role = [filter.role];
        // usersList = await userModel.getUser(filter, role, res);
        usersList = await userModel.getUser(page, filter, res);

        successHandler.successHandler(200, 'User List Fetch', res, usersList)

    } catch (error) {
        console.log(error, 'error')
        errorHandler.errorHandler(500, 'Server error occurred', res)
    }
};
const getUserById = async (username, filter, res) => {
    try {
        let usersList = []
        const userDetails = await userModel.getUserByUsername(username, res);

        if (!userDetails && !userDetails.find({ "profile.admin": true })) {
            errorHandler.errorHandler(403, 'Unauthorised user', res)
            return
        }

        usersList = await userModel.getUserById(filter.id, res);
        successHandler.successHandler(200, 'User Fetched', res, usersList)
    } catch (error) {
        console.log(error, 'error')
        errorHandler.errorHandler(500, 'Server error occurred', res)
    }
};
const updateUser = async (username, userId, updateData, res) => {
    try {
        let updated = false
        const userDetails = await userModel.getUserByUsername(username, res);

        if (!userDetails && !userDetails.find({ "profile.admin": true })) {
            errorHandler.errorHandler(403, 'Unauthorised user', res)
            return
        }
        // user who updated the details
        // updateData.updatedBy = userDetails._id
        updated = await userModel.updateUser(userId, updateData, res);

        successHandler.successHandler(200, 'User access updated successfully.', res, updated)
    } catch (error) {
        console.log(error, 'error')
        errorHandler.errorHandler(400, error, res)
    }
};

const signout = async (username, res) => {
    try {
        const userDetails = await userModel.getUserByUsername(username, res);

        if (!userDetails && !userDetails.find({ "profile.admin": true })) {
            errorHandler.errorHandler(403, 'Unauthorised user', res)
            return
        }
        await userModel.signout(username, res);
    } catch (error) {
        errorHandler.errorHandler(500, 'Server error occurred', res)
    }
};

// being used in csa
// const getRefreshToken = async (Username, res) => {
//     try {
//         const userDetails = await userModel.getUserByEmail(Username, res);
//         if (!userDetails || !userDetails.isAccountActive) {
//             errorHandler.errorHandler(403, 'Unauthorised user', res)
//             return
//         }
//         await userModel.getRefreshToken(Username, userDetails, res);
//     } catch (error) {
//         errorHandler.errorHandler(500, 'Server error occurred', res)
//     }
// };




// being used in csa
const verifyUser = async (loginDetails, res) => {

    try {
        // without token login end
        const connection = await connectionMethod.getConnection();
        // execute will internally call prepare and query
        const user = await models.User.findOne({ username: loginDetails.username });

        if (!user) {
            errorHandler.errorHandler(400, 'No such user found. Please check your Username', res)
            return
        }
        // check user organisation
        // for application super admin validate and let them login through any portal
        if (user.profile.admin != true) {
            errorHandler.errorHandler(400, 'No such ADMIN found. Please check Role', res)
            return
        }
        const userDetails = user;
        // console.log(userDetails.password)
        // verify password

        // const passwordIsValid = bcrypt.compareSync(
        //     loginDetails.password,
        //     userDetails.password
        // );
        const passwordIsValid = true;

        if (!passwordIsValid) {
            errorHandler.errorHandler(401, 'Invalid password. Authentication failed.', res)
            return
        }
        // identify role of the user
        // create session
        const token = jwt.sign({ id: userDetails.username }, authKey, {
            expiresIn: 3600 // 1 hour
        });

        let response = {
            userId: `${userDetails.profile._id}`,
            username: userDetails.username,
            fullName: `${userDetails.profile.firstName} ${userDetails.profile.lastName}`,
            email: userDetails.emails[0].address,
            role: userDetails.roles,
            admin: userDetails.profile.admin,
            verified: userDetails.profile.verified,
            accessToken: token,
            // passwordReset: userDetails.passwordReset
        };
        // closed connection
        // await connectionMethod.closeConnection();
        successHandler.successHandler(200, 'Successfully logged in.', res, response)
    } catch (error) {
        console.log(error, 'error')
        errorHandler.errorHandler(500, 'Server error occurred', res)
    }

};
const insertUser = async (username, payloadData, res) => {

    try {

        const userDetails = await userModel.getUserByUsername(username, res);

        if (!userDetails && !userDetails.find({ "profile.admin": true })) {
            errorHandler.errorHandler(403, 'Unauthorised user', res)
            return
        }
        // const validatedAdminPromotion = adminPromotionValidations.insertUserValidations(payloadData, res)


        // if (validatedAdminPromotion) {
        //     const data = await adminPromotionsModel.insertUserList(payloadData, res);

        //     successHandler.successHandler(200, 'Admin Promotions created successfully', res, data);
        // }

        const data = await userModel.insertUserList(payloadData, res);

        successHandler.successHandler(200, 'Add User created successfully', res, data);

    } catch (error) {
        console.log(error, 'error')
        errorHandler.errorHandler(500, 'Server error occurred', res)
    }


};

const getProfile = async (username, res) => {
    try {
        const userDetails = await userModel.getUserByUsername(username, res);

        if (!userDetails && !userDetails.find({ "profile.admin": true })) {
            errorHandler.errorHandler(403, 'Unauthorised user', res)
            return
        }

        const user = await models.User.findOne({ username: username });
        let response = {

            fullName: `${userDetails.profile.firstName} ${userDetails.profile.lastName}`,
            email: userDetails.emails[0].address,
            role: userDetails.roles,

        };

        successHandler.successHandler(200, 'Admin Profile Details Fetched', res, response)
    } catch (error) {
        console.log(error, 'error')
        errorHandler.errorHandler(500, 'Server error occurred', res)
    }
};
const getUserData = async (username, res) => {
    try {
        const userDetails = await userModel.getUserByUsername(username, res);

        if (!userDetails && !userDetails.find({ "profile.admin": true })) {
            errorHandler.errorHandler(403, 'Unauthorised user', res)
            return
        }


        const coachesList = await userModel.getCoachesByCoachname("COACH", res);
        const athleteList = await userModel.getAthletesByAthletename("ATHLETE", res);
        const agentList = await userModel.getAgentsByAgentname("AGENT", res);


        let response = {
            totalUsers: coachesList.length + athleteList.length + agentList.length,
            noOfCoaches: coachesList.length,
            noOfathletes: athleteList.length,
            noOfagents: agentList.length
        };
        successHandler.successHandler(200, 'Admin Profile Details Fetched', res, response)
    } catch (error) {
        console.log(error, 'error')
        errorHandler.errorHandler(500, 'Server error occurred', res)
    }
};

const getRefreshToken = async (username, res) => {
    try {
        const userDetails = await userModel.getUserByUsername(username, res);

        if (!userDetails && !userDetails.find({ "profile.admin": true })) {
            errorHandler.errorHandler(403, 'Unauthorised user', res)
            return
        }
        await userModel.getRefreshToken(username, userDetails, res);
    } catch (error) {
        errorHandler.errorHandler(500, 'Server error occurred', res)
    }
};

const getFileUpload = async (username, userId, uploadData, res) => {

    console.log("uploadData Path", uploadData.path)
    console.log("uploadData", uploadData)


    try {

        const userDetails = await userModel.getUserByUsername(username, res);

        if (!userDetails && !userDetails.find({ "profile.admin": true })) {
            errorHandler.errorHandler(403, 'Unauthorised user', res)
            return
        }

        result = await userModel.uploadUserFile(userId, uploadData, res);

        successHandler.successHandler(200, 'File Uploaded successfully.', res, result)

    } catch (error) {
        console.log(error, 'error')
        errorHandler.errorHandler(500, 'Server error occurred', res)
    }
};
const getCsvFileUpload = async (username, req, uploadData, res) => {



    try {
        // const connection = await connectionMethod.getConnection();

        const userDetails = await userModel.getUserByUsername(username, res);

        if (!userDetails && !userDetails.find({ "profile.admin": true })) {
            errorHandler.errorHandler(403, 'Unauthorised user', res)
            return
        }


        const results = [];

        fs.createReadStream(uploadData.path)

            .pipe(csv())
            .on('data', (data) => {
                results.push(data);
            })
            .on('end', () => {
                const transporter = nodemailer.createTransport({
                    service: 'gmail',
                    auth: {
                        user: 'testrobot79@gmail.com',
                        pass: 'gkiwotehjqfrgohx',
                    },
                });
                results.forEach((result) => {
                    const mailOptions = {
                        from: 'testrobot79@gmail.com',
                        to: result.email,
                        subject: result.subject,
                        text: result.text,
                    };

                    transporter.sendMail(mailOptions, (error, info) => {
                        if (error) {
                            console.log(error);
                        } else {
                            console.log('Email sent: ' + info.response);
                        }
                    });

                    const sentMessage = {
                        recipient: result.name,
                        email: result.email,
                        subject: result.subject,
                        text: result.text,
                    };
                });


            });




        // const parser = csv()
        //     .on('data', (data) => {
        //         results.push(data);
        //     })
        //     .on('end', () => {

        //         const file = new Email({
        //             name: uploadData.name,
        //             path: uploadData.path,
        //         });
        //         // const file = new File(uploadData);

        //         file.save()
        //             .then(() => {
        //                 res.status(200).send('File uploaded and saved to database');
        //             })
        //             .catch((err) => {
        //                 res.status(500).send(err);
        //             });
        //         req.file.pipe(parser);
        //     });


        // console.log(results, 'results')



        successHandler.successHandler(200, 'File Uploaded successfully.', res, results)

    } catch (error) {
        console.log(error, 'error')
        errorHandler.errorHandler(500, 'Server error occurred', res)
    }
};

const deleteUserId = async (username, filter, res) => {
    try {
        let usersList = []
        const userDetails = await userModel.getUserByUsername(username, res);

        if (!userDetails && !userDetails.find({ "profile.admin": true })) {
            errorHandler.errorHandler(403, 'Unauthorised user', res)
            return
        }

        usersList = await userModel.deleteUserId(filter.id, res);
        successHandler.successHandler(200, 'Deleted Successfully', res, usersList)
    } catch (error) {
        console.log(error, 'error')
        errorHandler.errorHandler(500, 'Server error occurred', res)
    }
};



const userService = {
    verifyUser,
    getUsersList,
    getUserById,
    updateUser,
    getProfile,
    getUserData,
    signout,
    getRefreshToken,
    getFileUpload,
    insertUser,
    getCsvFileUpload,
    deleteUserId

};

module.exports = userService;

