const errorHandler = require("../handler/errorHandler");
const successHandler = require("../handler/successHandler");
const userModel = require("../models/userModel");
const contactModel = require("../models/contactDataModel");
const models = require("../models");


const getContactDatas = async (username, res) => {

    try {

        const userDetails = await userModel.getUserByUsername(username, res);


        if (!userDetails && !userDetails.find({ "profile.admin": true })) {
            errorHandler.errorHandler(403, 'Unauthorised user', res)
            return
        }
        const list = await models.contact.find({}, {});
        // const list = await models.role.find({},{});

        console.log(list)

        // const role = await models.role.find({},"name");

        if (!list) {
            errorHandler.errorHandler(400, 'No such User Query list Found', res)
            return
        }

        // closed connection
        // await connectionMethod.closeConnection();
        successHandler.successHandler(200, 'Successfully User Query  List fetch', res, list)
    } catch (error) {
        console.log(error, 'error')
        errorHandler.errorHandler(500, 'Server error occurred', res)
    }


};
const getContactDatasById = async (username, filter, res) => {
    try {
        let usersList = []
        const userDetails = await userModel.getUserByUsername(username, res);

        if (!userDetails && !userDetails.find({ "profile.admin": true })) {
            errorHandler.errorHandler(403, 'Unauthorised user', res)
            return
        }

        usersList = await contactModel.getContactDatasByUserId(filter.id, res);
        successHandler.successHandler(200, 'ContactData Fetched', res, usersList)
    } catch (error) {
        console.log(error, 'error')
        errorHandler.errorHandler(500, 'Server error occurred', res)
    }
};

// const updateUser = async (username, paymentId, updateData, res) => {
//     try {
//         let updated = false
//         const userDetails = await userModel.getUserByUsername(username, res);

//         if (!userDetails && !userDetails.find({ "profile.admin": true })) {
//             errorHandler.errorHandler(403, 'Unauthorised user', res)
//             return
//         }
//         // user who updated the details
//         // updateData.updatedBy = userDetails._id
//         updated = await contactModel.updateUser(paymentId, updateData, res);

//         successHandler.successHandler(200, 'User access updated successfully.', res, updated)
//     } catch (error) {
//         console.log(error, 'error')
//         errorHandler.errorHandler(400, error, res)
//     }
// };


const contactService = {
    getContactDatas,
    getContactDatasById,
    // updateUser
};

module.exports = contactService;
