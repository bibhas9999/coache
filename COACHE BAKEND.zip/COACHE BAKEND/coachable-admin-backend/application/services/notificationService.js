const errorHandler = require("../handler/errorHandler");
const successHandler = require("../handler/successHandler");
const userModel = require("../models/userModel");
const coachNotificationModel = require("../models/coachNotificationSettingsModel");
const athleteNotificationModel = require("../models/athleteNotificationSettingsModel");
const models = require("../models");


const getCoachNotificationSettings = async (username, res) => {

    try {

        const userDetails = await userModel.getUserByUsername(username, res);


        if (!userDetails && !userDetails.find({ "profile.admin": true })) {
            errorHandler.errorHandler(403, 'Unauthorised user', res)
            return
        }
        const list = await models.coachNotification.find({}, {});
        // const list = await models.role.find({},{});

        console.log(list)

        // const role = await models.role.find({},"name");

        if (!list) {
            errorHandler.errorHandler(400, 'No such CoachNotification list Found', res)
            return
        }

        // closed connection
        // await connectionMethod.closeConnection();
        successHandler.successHandler(200, 'Successfully Notification Setting List fetch', res, list)
    } catch (error) {
        console.log(error, 'error')
        errorHandler.errorHandler(500, 'Server error occurred', res)
    }


};
const getAthleteNotificationSettings = async (username, res) => {

    try {

        const userDetails = await userModel.getUserByUsername(username, res);


        if (!userDetails && !userDetails.find({ "profile.admin": true })) {
            errorHandler.errorHandler(403, 'Unauthorised user', res)
            return
        }
        const list = await models.athleteNotification.find({}, {});
        // const list = await models.role.find({},{});

        console.log(list)

        // const role = await models.role.find({},"name");

        if (!list) {
            errorHandler.errorHandler(400, 'No such Notification Setting list Found', res)
            return
        }

        // closed connection
        // await connectionMethod.closeConnection();
        successHandler.successHandler(200, 'Successfully  Athlete Notification Setting List  fetch', res, list)
    } catch (error) {
        console.log(error, 'error')
        errorHandler.errorHandler(500, 'Server error occurred', res)
    }


};

const updateCoachSettings = async (username, coachId, updateData, res) => {
    try {
        let updated = false
        const userDetails = await userModel.getUserByUsername(username, res);

        if (!userDetails && !userDetails.find({ "profile.admin": true })) {
            errorHandler.errorHandler(403, 'Unauthorised user', res)
            return
        }
        // user who updated the details
        // updateData.updatedBy = userDetails._id
        console.log(updateData)
        updated = await coachNotificationModel.updateCoachUser(coachId, updateData, res);

        successHandler.successHandler(200, 'User access updated successfully.', res, updated)
    } catch (error) {
        console.log(error, 'error')
        errorHandler.errorHandler(400, error, res)
    }
};
const updateAthleteSettings = async (username, athleteId, updateData, res) => {
    try {
        let updated = false
        const userDetails = await userModel.getUserByUsername(username, res);

        if (!userDetails && !userDetails.find({ "profile.admin": true })) {
            errorHandler.errorHandler(403, 'Unauthorised user', res)
            return
        }
        // user who updated the details
        // updateData.updatedBy = userDetails._id
        updated = await athleteNotificationModel.updateAthleteUser(athleteId, updateData, res);

        successHandler.successHandler(200, 'User access updated successfully.', res, updated)
    } catch (error) {
        console.log(error, 'error')
        errorHandler.errorHandler(400, error, res)
    }
};


const notificationService = {
    getCoachNotificationSettings,
    getAthleteNotificationSettings,
    updateCoachSettings,
    updateAthleteSettings

};

module.exports = notificationService;
