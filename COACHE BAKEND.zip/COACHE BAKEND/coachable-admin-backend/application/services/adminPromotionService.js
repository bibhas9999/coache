const errorHandler = require("../handler/errorHandler");
const successHandler = require("../handler/successHandler");
const userModel = require("../models/userModel");
const adminPromotionsModel = require("../models/adminPromotionsModel");
const models = require("../models");
const adminPromotionValidations = require("../modelValidators/adminPromotionValidations");


const getPromotionalCouponList = async (username, res) => {

    try {

        const userDetails = await userModel.getUserByUsername(username, res);


        if (!userDetails && !userDetails.find({ "profile.admin": true })) {
            errorHandler.errorHandler(403, 'Unauthorised user', res)
            return
        }
        const list = await models.AdminPromotion.find({}, { name: 1, coupon_code: 1, usage_limit: 1, userType: 1, discount_percent: 1 });

        console.log(list)

        // const role = await models.role.find({},"name");

        if (!list) {
            errorHandler.errorHandler(400, 'No such Promotional Coupon Found', res)
            return
        }

        // closed connection
        // await connectionMethod.closeConnection();
        successHandler.successHandler(200, 'Successfully PromotionalCouponList fetch', res, list)
    } catch (error) {
        console.log(error, 'error')
        errorHandler.errorHandler(500, 'Server error occurred', res)
    }


};

// Create Promotional Coupon

const createAdminPromotion = async (username, payloadData, res) => {

    try {

        const userDetails = await userModel.getUserByUsername(username, res);

        if (!userDetails && !userDetails.find({ "profile.admin": true })) {
            errorHandler.errorHandler(403, 'Unauthorised user', res)
            return
        }
        const validatedAdminPromotion = adminPromotionValidations.createAdminPromotionValidations(payloadData, res)


        if (validatedAdminPromotion) {
            const data = await adminPromotionsModel.createAdminPromotionList(payloadData, res);

            successHandler.successHandler(200, 'Admin Promotions created successfully', res, data);
        }
    } catch (error) {
        console.log(error, 'error')
        errorHandler.errorHandler(500, 'Server error occurred', res)
    }


};





const adminPromotionService = {
    getPromotionalCouponList,
    createAdminPromotion

};

module.exports = adminPromotionService;

