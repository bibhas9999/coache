const validator = require("../library/validations");
const errorHandler = require("../handler/errorHandler");
// all necessary validations while adding a new user
exports.userValidations = async (payloadData, res) => {
    console.log(payloadData.email)
    try {
        let validated = false
        validator.validStringData('First Name', payloadData.firstName)
        validator.validStringData('Last Name', payloadData.lastName)
        validator.validEmail('Email', payloadData.email)
        // validator.validPhoneNumber('Contact Number', user.contactNumber)
        // // validator.validStringData('Address', user.address)
        // validator.validStringData('Grade', user.grade)
        // validator.validNumber('Date of Birth', user.dob)
        // validator.validDOB('Date of Birth', user.dob)
        validated = validator.validUserName('Username', payloadData.username)
        return validated
    } catch (error) {
        errorHandler.errorHandler(400, error, res);
        return false
    }
};


exports.loginValidations = (loginDetails, res) => {

    try {

        validator.validUserName('Username', loginDetails.username)
        validator.validPassword('Password', loginDetails.password)

        return true
    } catch (error) {
        errorHandler.errorHandler(400, error, res);
        // res.status(400).send({ status: 400, message: error });
        return false
    }
};

exports.UserValidations = (details, res) => {

    try {
        if (details.role) {
            validator.validUserRole('Role', details.role)
        }
        if (details.username) {
            validator.validUserName('Username', details.username)
        }
        if (details.email) {
            validator.validEmail('Email', details.email)
        }

        return true



    } catch (error) {
        errorHandler.errorHandler(400, error, res);
        // res.status(400).send({ status: 400, message: error });
        return false
    }
};

exports.UserIdValidations = (details, res) => {

    try {
        if (details.athleteId) {
            validator.validStringData('AthleteId', details.athleteId)
        }
        if (details.coachId) {
            validator.validStringData('CoachId', details.coachId)
        }

        return true



    } catch (error) {
        errorHandler.errorHandler(400, error, res);
        // res.status(400).send({ status: 400, message: error });
        return false
    }
};
exports.UserNameValidations = (details, res) => {

    try {
        if (details.athleteName) {
            validator.validStringData('athleteName', details.athleteName)
        }
        if (details.coachName) {
            validator.validStringData('coachName', details.coachName)
        }

        return true



    } catch (error) {
        errorHandler.errorHandler(400, error, res);
        // res.status(400).send({ status: 400, message: error });
        return false
    }
};





exports.emailValidation = (email, res) => {
    try {
        validator.validEmail('Email', email)
        return true
    } catch (error) {
        errorHandler.errorHandler(400, error, res);
        // res.status(400).send({ status: 400, message: error });
        return false
    }
};

exports.requiredDataValidation = async (name, data, res) => {
    try {
        let validated = true
        validator.validStringData(name, data)
        return validated
    } catch (error) {
        errorHandler.errorHandler(400, error, res);
        return false
    }
};

exports.updateUserValidations = (userId, updateData, res) => {
    try {
        validator.validStringData('Id', userId)
        validator.validUserRole('Role', updateData.roleName)
        return true
    } catch (error) {
        errorHandler.errorHandler(400, error, res);
        // res.status(400).send({ status: 400, message: error });
        return false
    }
};