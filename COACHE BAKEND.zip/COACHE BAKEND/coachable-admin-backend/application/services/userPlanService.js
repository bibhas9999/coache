const errorHandler = require("../handler/errorHandler");
const successHandler = require("../handler/successHandler");
const userModel = require("../models/userModel");
const userPlanModel = require("../models/userPlanModel");
const models = require("../models");
const userPlanValidations = require("../modelValidators/userPlanValidations");


const getUserPlanList = async (username, res) => {

    try {

        const userDetails = await userModel.getUserByUsername(username, res);


        if (!userDetails && !userDetails.find({ "profile.admin": true })) {
            errorHandler.errorHandler(403, 'Unauthorised user', res)
            return
        }
        const list = await models.UserPlans.find({}, {});

        console.log(list)

        // const role = await models.role.find({},"name");

        if (!list) {
            errorHandler.errorHandler(400, 'No such UserPlan Found', res)
            return
        }

        // closed connection
        // await connectionMethod.closeConnection();
        successHandler.successHandler(200, 'Successfully UserPlan List fetch', res, list)
    } catch (error) {
        console.log(error, 'error')
        errorHandler.errorHandler(500, 'Server error occurred', res)
    }


};

//Create User Plan

const createUserPlan = async (username, payloadData, res) => {

    try {

        const userDetails = await userModel.getUserByUsername(username, res);

        if (!userDetails && !userDetails.find({ "profile.admin": true })) {
            errorHandler.errorHandler(403, 'Unauthorised user', res)
            return
        }
        const validatedUserPlan = userPlanValidations.createUserPlanValidations(payloadData, res)


        if (validatedUserPlan) {

            const data = await userPlanModel.createUserPlanList(payloadData, res);
            console.log(data)
            successHandler.successHandler(200, 'User Plan created successfully', res, data);
        }
    } catch (error) {
        console.log(error, 'error')
        errorHandler.errorHandler(500, 'Server error occurred', res)
    }


};

const getParticularUserPlan = async (username, filter, res) => {

    try {

        const userDetails = await userModel.getUserByUsername(username, res);


        if (!userDetails && !userDetails.find({ "profile.admin": true })) {
            errorHandler.errorHandler(403, 'Unauthorised user', res)
            return
        }
        const list = await models.UserPlans.findOne(filter);


        // const role = await models.role.find({},"name");

        if (!list) {
            errorHandler.errorHandler(400, 'No such UserPlan Found', res)
            return
        }

        // closed connection
        // await connectionMethod.closeConnection();
        successHandler.successHandler(200, 'Successfully UserPlan List fetch', res, list)
    } catch (error) {
        console.log(error, 'error')
        errorHandler.errorHandler(500, 'Server error occurred', res)
    }


};




const userPlanService = {
    getUserPlanList,
    createUserPlan,
    getParticularUserPlan
};

module.exports = userPlanService;

