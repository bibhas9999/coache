
const models = require(".");
const connectionMethod = require("../../config/db.connection");
const config = require('../../config');
const authKey = config.get('auth.secret');
const tableName = 'users'

// being used in coach
const getAthleteByAthleteId = async (username, res) => {



    try {
        const connection = await connectionMethod.getConnection();
        // execute will internally call prepare and query
        const athlete = await models.message.find({ athleteId: username }, "_id");
        // end connection
        // await connectionMethod.closeConnection();
        return athlete;
    } catch (error) {
        throw error
    }
};

const getCoachByCoachId = async (userId, res) => {

    try {
        const connection = await connectionMethod.getConnection();
        // execute will internally call prepare and query
        const coach = await models.message.find({ coachId: userId }, "_id");
        // end connection
        // await connectionMethod.closeConnection();
        return coach;
    } catch (error) {
        throw error
    }
};


const messageModel = {

    getCoachByCoachId,
    getAthleteByAthleteId,

};

module.exports = messageModel;

