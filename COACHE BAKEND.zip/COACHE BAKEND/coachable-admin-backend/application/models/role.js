const mongoose = require('mongoose')
const mongooseSchema = mongoose.Schema
const roleSchema = new mongooseSchema({

    _id: { type: String },
    name: {
        type: String,
        default: '',
        trim: true
    },
    fees: {
        type: Number,
        default: ''
    },

});
const role = mongoose.model('roles', roleSchema);
module.exports = role

