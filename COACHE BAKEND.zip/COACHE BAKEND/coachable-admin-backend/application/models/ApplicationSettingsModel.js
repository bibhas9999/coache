
const models = require("../models");
const connectionMethod = require("../../config/db.connection");
const config = require('../../config');



const updateUser = async (applicationId, updateData, res) => {
    try {
        const connection = await connectionMethod.getConnection();
        // execute will internally call prepare and query
        const updated = await models.application.findOneAndUpdate({ _id: applicationId }, updateData);
        console.log(updated, "updated")
        // end connection
        connectionMethod.closeConnection();
        return updated;
    } catch (error) {
        console.log(error, 'error')
        throw error
    }
};



const applicationModel = {
    updateUser,
   
};

module.exports = applicationModel;

