const mongoose = require('mongoose')
const mongooseSchema = mongoose.Schema
const messageSchema = new mongooseSchema({

    _id: {
        type: String

    },
    athleteId: {
        type: String,
        default: ''
    },
    coachId: {
        type: String,
        default: ''
    },
    wasOpenedAndRead: {
        type: Boolean,
        default: 'true'
    },
    messages: {
        type: Array,
        default: ''
    },
    visibleToCoach: {
        type: Boolean,
        default: 'false'
    },
    updatedAt: {
        type: Number,
        default: new Date().getTime()
    },



});
const message = mongoose.model('messagethreads', messageSchema);
module.exports = message

