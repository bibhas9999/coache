const connectionMethod = require("../../config/db.connection");
const errorHandler = require("../handler/errorHandler");
const models = require("../models");

// being used in csa
const verifyUserCode = async (payloadData, res) => {
    try {
        let verified = false
        const connection = await connectionMethod.getConnection();
        // execute will internally call prepare and query
        const forgotUser = await models.ForgotPassword.findOneAndUpdate({ email: payloadData.email, codeVerified: false, verificationCode: payloadData.verificationCode }, { updatedAt: new Date().getTime(), verificationCode: null, codeVerified: true });
        if (forgotUser) {
            //verified successfully after code match
            verified = true;
        } else {
            errorHandler.errorHandler(400, 'Incorrect verfication code. Please try again.', res)
            return
        }
        // end connection
        connectionMethod.closeConnection();
        return verified;
    } catch (error) {
        console.log(error, 'error')
        errorHandler.errorHandler(500, 'Server error occurred', res)
    }
};

// being used in csa
const storeVerificationCode = async (userDetails, code, res) => {
    try {
        let sentCode = false
        const userId = userDetails._id
        const connection = await connectionMethod.getConnection();
        // execute will internally call prepare and query
        const forgotUser = await models.ForgotPassword.findOne({ userId, codeVerified: false });
        if (forgotUser) {
            // just send previous code
            sentCode = forgotUser.verificationCode;
        } else {
            // insert new one
            const newForgotUser = {
                userId,
                email: userDetails.email,
                verificationCode: code,
                codeVerified: false,
                createdAt: new Date().getTime(),
                updatedAt: new Date().getTime()
            }
            const forgotUserObj = new models.ForgotPassword(newForgotUser)
            const inserted = await forgotUserObj.save();
            if (inserted) {
                sentCode = code
            }
        }
        // end connection
        connectionMethod.closeConnection();
        return sentCode;
    } catch (error) {
        console.log(error, 'error')
        throw error
    }
};

const poModel = {
    storeVerificationCode,
    verifyUserCode
};

module.exports = poModel;