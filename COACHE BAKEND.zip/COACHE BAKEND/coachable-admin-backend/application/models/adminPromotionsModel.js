const models = require("../models");
const userModel = require("../models/userModel");
const connectionMethod = require("../../config/db.connection");
const errorHandler = require("../handler/errorHandler");
const successHandler = require("../handler/successHandler");
const config = require('../../config');
const path = require('path');

// Being use in create userplan
const createAdminPromotionList = async (newAdminPromotion, res) => {

    try {
        // Plan  created date
        newAdminPromotion._id = new Date().getTime()

        const connection = await connectionMethod.getConnection();
        let newCoupon = new models.AdminPromotion(newAdminPromotion);
        console.log(newCoupon)
        const saved = await newCoupon.save()
        if (!saved) {
            errorHandler.errorHandler(500, 'Error in adding new  user plan.', res)
            return
        }
        // set plan id
        newAdminPromotion._id = saved._id
        // end connection
        connectionMethod.closeConnection();
        return newAdminPromotion
    } catch (error) {
        console.log(error)
        throw error
    }
};

const adminPromotionsModel = {
    createAdminPromotionList
};

module.exports = adminPromotionsModel;

