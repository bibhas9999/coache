const mongoose = require('mongoose')
const mongooseSchema = mongoose.Schema
const msgTemplateSchema = new mongooseSchema({

    _id: { type: String },
    // userplanId: {
    //     type: mongoose.Schema.Types.ObjectId,
    //     required: true
    // },
    createdAt: {
        type: Date,
        default: new Date().getTime()
    },
    templateName: {
        type: String,
        default: '',
        trim: true

    },
    message: {
        type: String,
        default: '',
        trim: true
    }

});
const msgTemplate = mongoose.model('messagetemplates', msgTemplateSchema);
module.exports = msgTemplate

