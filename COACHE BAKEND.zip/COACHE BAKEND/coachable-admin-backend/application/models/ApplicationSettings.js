const mongoose = require('mongoose')
const mongooseSchema = mongoose.Schema
const applicationSchema = new mongooseSchema({

    _id: { type: String },
    aboutUs: {
        type: String,
        default: ''
    },
    privacyPolicy: {
        type: String,
        default: ''
    },
    frequentlyAskedQuestions: {
        type: String,
        default: ''
    },
    termsAndConditions: {
        type: String,
        default: ''
    },
    introductoryVideo: {
        type: String,
        default: ''
    },
    additionalCreditGainPercentageOnWebSignup: {
        type: Number,
        default: ''
    },


});
const application = mongoose.model('applicationsettings', applicationSchema);
module.exports = application

