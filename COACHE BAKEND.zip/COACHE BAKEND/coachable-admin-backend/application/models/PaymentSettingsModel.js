
const models = require("../models");
const connectionMethod = require("../../config/db.connection");
const config = require('../../config');



const updateUser = async (paymentId, updateData, res) => {
    try {
        const connection = await connectionMethod.getConnection();
        // execute will internally call prepare and query
        const updated = await models.payment.findOneAndUpdate({ _id: paymentId }, updateData);
        console.log(updated, "updated")
        // end connection
        connectionMethod.closeConnection();
        return updated;
    } catch (error) {
        console.log(error, 'error')
        throw error
    }
};



const paymentModel = {
    updateUser,
   
};

module.exports = paymentModel;

