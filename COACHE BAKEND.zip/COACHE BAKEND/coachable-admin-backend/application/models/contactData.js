const mongoose = require('mongoose')
const mongooseSchema = mongoose.Schema
const contactSchema = new mongooseSchema({

    _id: { type: String },
    userId: {
        type: String,
        default: ''
    },
    sentReply: {
        type: Boolean,
        default: ''
    },
    reply: {
        type: String,
        default: ''
    },
    message: {
        type: String,
        default: ''
    },
    dateCreated: {
        type: Date,
        default: new Date().getTime()
    },
    name: {
        type: String,
        default: ''
    },
    email: {
        type: String,
        default: ''
    },
    subject: {
        type: String,
        default: ''
    },
    file: {
        type: String,
        default: ''
    },


});
const contact = mongoose.model('contactdatas', contactSchema);
module.exports = contact

