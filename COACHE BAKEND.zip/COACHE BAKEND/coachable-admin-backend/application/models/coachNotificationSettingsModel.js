
const models = require(".");
const connectionMethod = require("../../config/db.connection");
const config = require('../../config');



const updateCoachUser = async (coachId, updateData, res) => {
    try {
        const connection = await connectionMethod.getConnection();
        // execute will internally call prepare and query
        const updated = await models.coachNotification.findOneAndUpdate({ _id: coachId }, updateData);
        console.log(updated, "updated")
        // end connection
        connectionMethod.closeConnection();
        return updated;
    } catch (error) {
        console.log(error, 'error')
        throw error
    }
};



const coachNotificationModel = {
    updateCoachUser,

};

module.exports = coachNotificationModel;

