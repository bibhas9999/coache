const models = require("../models");
const userModel = require("../models/userModel");
const connectionMethod = require("../../config/db.connection");
const errorHandler = require("../handler/errorHandler");
const successHandler = require("../handler/successHandler");
const config = require('../../config');
const path = require('path');

// Being use in create userplan
const createUserPlanList = async ( newUserplan, res) => {
    
    try {
        // Plan  created date
        newUserplan._id=
        newUserplan.createdDate = new Date().getTime()
        newUserplan.updatedAt = new Date().getTime()
        const connection = await connectionMethod.getConnection();
        let newplan = new models.UserPlans(newUserplan);
        console.log(newplan)
        const saved = await newplan.save()
        if (!saved) {
            errorHandler.errorHandler(500, 'Error in adding new  user plan.', res)
            return
        }
        // set plan id
        newUserplan._id = saved._id
        // end connection
        connectionMethod.closeConnection();
        return newUserplan
    } catch (error) {
        console.log(error)
        throw error
    }
};

const getUser = async (filter, res) => {
  
    try {
        const connection = await connectionMethod.getConnection();
        // execute will internally call prepare and query
      
       
        //  const user = await models.User.find({"roles.0":filter.role});
         const user = await models.User.find(filter);
        
        // end connection
        // await connectionMethod.closeConnection();
        return user;
    } catch (error) {
        throw error
    }
};


const userPlanModel = {
    createUserPlanList
};

module.exports = userPlanModel;

