const mongoose = require('mongoose')
const mongooseSchema = mongoose.Schema


const emailSchema = new mongooseSchema({

    _id: {
        type: String

    },
    recipient: {
        type: String,
        default: ''
    },
    email: {
        type: String,
        default: ''
    },
    subject: {
        type: String,
        default: ''
    },
    text: {
        type: String,
        default: ''
    },
    date: {
        type: Date,
        default: Date.now
    }

});

const Email = mongoose.model('sentmessages', emailSchema);
module.exports = Email;

