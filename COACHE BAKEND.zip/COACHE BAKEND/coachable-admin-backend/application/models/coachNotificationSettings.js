const mongoose = require('mongoose')
const mongooseSchema = mongoose.Schema
const notificationSchema = new mongooseSchema({

    _id: { type: String },
    newMessages: {
        type: Boolean,
        default: ''
    },
    newSubscriptionSold: {
        type: Boolean,
        default: ''
    },
    newPackageSold: {
        type: Boolean,
        default: ''
    },
    newVideoSubmitted: {
        type: Boolean,
        default: ''
    },


});
const coachNotification = mongoose.model('coachnotificationsettings', notificationSchema);
module.exports = coachNotification

