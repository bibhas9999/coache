const mongoose = require('mongoose')
const mongooseSchema = mongoose.Schema
const userPlanSchema = new mongooseSchema({

    _id:  { type:String},
    // userplanId: {
    //     type: mongoose.Schema.Types.ObjectId,
    //     required: true
    // },
    createdAt: {
        type: Date,
        default: new Date().getTime()
    },
    updatedAt: {
        type: Date,
        default: new Date().getTime()
    },
    disabled: {
        type: Boolean,
        default: false
    },
    oneTimeFee: {
        type: Number,
        default: ''
    },
    paymentType: {
        type: String,
        default: '',
        trim: true

    },
    paymentInterval: {
        type: String,
        default: '',
        trim: true
    },
    paymentAmount: {
        type: Number,
        default: ''
    },
    allowedStorage: {
        type: Number,
        default: ''
    },
    planName: {
        type: String,
        default: '',
        trim: true
    },
    userType: {
        type: String,
        default: '',
        trim: true
    },
    description: {
        type: String,
        default: '',
        trim: true
    },
});
const UserPlans = mongoose.model('userplans', userPlanSchema);
module.exports = UserPlans

