const mongoose = require('mongoose')
const mongooseSchema = mongoose.Schema

const UserSchema = new mongooseSchema({

    _id: {
        type: String
    },

    commissionPartners: {
        type: Array,
        default: '',
        trim: true
    },
    referralCode: {
        type: String,
        default: '',
        min: 16,
        max: 20,
        trim: true

    },
    createdAt: {
        type: Date,
        default: new Date().getTime()
    },
    services: {
        id: { type: String },
        resume: {
            id: { type: String },
            loginTokens: { type: [String] },
        },
        password: {
            id: { type: String },
            bcrypt: { type: String },
        }
    },
    username: {
        type: String,
        //Username must be required(ERROR)
        required: [true, "Username required"],
        default: null
    },
    emails: [
        {
            verified: {
                type: Boolean,
                default: false
            },
            id: { type: String },
            address: {
                type: Array,
                unique: true,
                lowercase: true,
                default: '',
                required: true,
                trim: true
            }
        },

    ],


    profile: {
        verified: {
            type: Boolean,
            default: true
        },
        isAccountDisabled: {
            type: Boolean,
            default: false
        },
        admin: {
            type: Boolean,
            default: true
        },
        lead: {
            type: Boolean,
            default: true
        },
        _id: { type: String },
        lastName: {
            type: String,
            default: '',
            trim: true
        },
        firstName: {
            type: String,
            default: '',
            trim: true
        },
        termsAgreedDate: {
            type: Number,
            default: new Date().getTime()

        },
        verificationCode: {
            type: Number,
            default: " "
        },
        onboardingCompletion: {
            welcomeVideoAcknowledged: {
                type: Boolean,
                default: true
            },
            termsAgreed: {
                type: Boolean,
                default: true
            },
            stripeConnectSetup: {
                type: Boolean,
                default: true
            },
            stripeCustomerSetup: {
                type: Boolean,
                default: false
            },
            paymentConfigured: {
                type: Boolean,
                default: true
            },
            initialOnboarding: {
                type: Boolean,
                default: true
            },
            id: { type: mongooseSchema.ObjectId }

        }

    },
    roles: [
        {
            type: String,
            default: ''
        }

    ],

    disabled: {
        //Incase of true /false ,we put Boolean
        type: Boolean,
        default: false
    },
    disabled_reason: {
        type: String,
        default: ''
    },
    // password: {
    //     type: String,
    //     default: '',
    //     min: 8,
    //     max: 16,
    //     required: true,
    //     trim: true
    // },
    // token: {
    //     type: String,
    //     default: '',
    //     min: 12,
    //     max: 16,
    //     trim: true
    // },

    updatedAt: {
        type: Number,
        default: new Date().getTime()
    },
    allowedStorage: {
        type: Number,
        default: ''
    },
    usedStorage: {
        images: {
            type: Number,
            default: ''
        },
        others: {
            type: Number,
            default: ''
        },
        pdfs: {
            type: Number,
            default: ''
        },
        total: {
            type: Number,
            default: ''
        },
        videos: {
            type: Number,
            default: ''
        }


    },
    // email: {
    //     type: String,
    //     unique: true,
    //     lowercase: true,
    //     default: '',
    //     required: true,
    //     trim: true,
    //     // validate: [validateEmail, "enter correct email"]
    // },
    firstTierReferrerPercentage: {
        type: Number,
        default: ''
    },
    secondTierReferrerPercentage: {
        type: Number,
        default: ''
    },
    thirdTierReferrerPercentage: {
        type: Number,
        default: ''
    },
    subscriptionFees: {
        type: Number,
        default: ''
    },
    userPlanId: {
        type: String,
        default: ''

    },
    referralImage: {
        type: String,
        default: ''
    },
    referralImageContentId: {
        type: String,
        default: ''

    },
    referralMessage: {
        type: String,
        default: ''

    },
    packagePurchased: {
        type: String,
        default: ''
    },
    userDeleted: {
        type: Boolean,
        default: false
    },
    planStatus: {
        type: String
    },
    avatar: {
        type: String,
        default: ''
    }


});


//configuring different access level for the USER
// UserSchema.plugin(require('mongoose-role'), {
//     roles: configurationHolder.config.roles,
//     accessLevels: configurationHolder.config.accessLevels
// });

const User = mongoose.model('users', UserSchema);
module.exports = User
