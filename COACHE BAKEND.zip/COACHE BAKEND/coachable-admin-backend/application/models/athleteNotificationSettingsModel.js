
const models = require(".");
const connectionMethod = require("../../config/db.connection");
const config = require('../../config');



const updateAthleteUser = async (athleteId, updateData, res) => {
    try {
        const connection = await connectionMethod.getConnection();
        // execute will internally call prepare and query
        const updated = await models.athleteNotification.findOneAndUpdate({ _id: athleteId }, updateData);
        console.log(updated, "updated")
        // end connection
        connectionMethod.closeConnection();
        return updated;
    } catch (error) {
        console.log(error, 'error')
        throw error
    }
};



const athleteNotificationModel = {
    updateAthleteUser,

};

module.exports = athleteNotificationModel;

