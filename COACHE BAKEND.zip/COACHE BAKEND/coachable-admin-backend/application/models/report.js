const mongoose = require('mongoose')
const mongooseSchema = mongoose.Schema
const reportSchema = new mongooseSchema({

    _id: {
        type: String

    },
    title: {
        type: String,
        default: ''
    },
    details: {
        type: String,
        default: ''
    },
    athleteId: {
        type: String,
        default: ''
    },
    coachId: {
        type: String,
        default: ''
    },
    whoReported: {
        type: String,
        default: ''
    },
    reportStatus: {
        type: String,
        default: ''
    },



});
const report = mongoose.model('reports', reportSchema);
module.exports = report

