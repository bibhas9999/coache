const mongoose = require('mongoose')
const mongooseSchema = mongoose.Schema
const notificationSchema = new mongooseSchema({

    _id: { type: String },
    newMessages: {
        type: Boolean,
        default: ''
    },
    critiqueReceived: {
        type: Boolean,
        default: ''
    },
    packageSubscriptionCreated: {
        type: Boolean,
        default: ''
    },
    promotionalMessages: {
        type: Boolean,
        default: ''
    },



});
const athleteNotification = mongoose.model('athletenotificationsettings', notificationSchema);
module.exports = athleteNotification

