const User = require("./User");
const role = require("./role");
const UserPlans = require("./UserPlan");
const payment = require("./PaymentSettings");
const application = require("./ApplicationSettings");
const message = require("./message");
const AdminPromotion = require("./adminPromotions");
const athleteNotification = require("./athleteNotificationSettings");
const coachNotification = require("./coachNotificationSettings");
const contact = require("./contactData")
const report = require("./report")
const Email = require("./csvFile")
const msgTemplate = require("./msgTemplate");


module.exports.User = User
module.exports.role = role
module.exports.UserPlans = UserPlans
module.exports.payment = payment
module.exports.application = application
module.exports.message = message
module.exports.AdminPromotion = AdminPromotion
module.exports.athleteNotification = athleteNotification
module.exports.coachNotification = coachNotification
module.exports.contact = contact
module.exports.report = report
module.exports.Email = Email
module.exports.msgTemplate = msgTemplate
