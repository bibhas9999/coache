
const jwt = require("jsonwebtoken");
const models = require("../models");
const connectionMethod = require("../../config/db.connection");
const errorHandler = require("../handler/errorHandler");
const successHandler = require("../handler/successHandler");
const config = require('../../config');
const authKey = config.get('auth.secret');


// being used in coach
const getUserByUsername = async (username, res) => {
    try {
        const connection = await connectionMethod.getConnection();
        // execute will internally call prepare and query
        const users = await models.User.findOne({ username });
        // end connection
        // await connectionMethod.closeConnection();
        return users;
    } catch (error) {
        throw error
    }
};
const getCoachesByCoachname = async (COACH, res) => {
    try {
        const connection = await connectionMethod.getConnection();
        // execute will internally call prepare and query
        const users = await models.User.find({ roles: COACH });
        // end connection
        // await connectionMethod.closeConnection();
        return users;
    } catch (error) {
        throw error
    }
};
const getAthletesByAthletename = async (ATHLETE, res) => {
    try {
        const connection = await connectionMethod.getConnection();
        // execute will internally call prepare and query
        const users = await models.User.find({ roles: ATHLETE });
        // end connection
        // await connectionMethod.closeConnection();
        return users;
    } catch (error) {
        throw error
    }
};
const getAgentsByAgentname = async (AGENT, res) => {
    try {
        const connection = await connectionMethod.getConnection();
        // execute will internally call prepare and query
        const users = await models.User.find({ roles: AGENT });
        // end connection
        // await connectionMethod.closeConnection();
        return users;
    } catch (error) {
        throw error
    }
};
const getCoachesNameList = async (coachList, res) => {
    try {
        const connection = await connectionMethod.getConnection();
        console.log(coachList.length)
        let users;
        for (let i = 0; i < coachList.length; i++) {

            users = await models.User.find({ _id: coachList[i].coachId }, "profile.firstName");
            // end connection
            // await connectionMethod.closeConnection();
            console.log(users)
            // return users;


        }



        // end connection
        // await connectionMethod.closeConnection();
        return users;
    } catch (error) {
        throw error
    }
};
const getAthleteNameList = async (athleteList, res) => {
    try {
        const connection = await connectionMethod.getConnection();
        // execute will internally call prepare and query
        const users = await models.User.find({ _id: athleteList[10].athleteId });
        // end connection
        // await connectionMethod.closeConnection();
        return users;
    } catch (error) {
        throw error
    }
};
// being used in athlete
const getUserByName = async (filter, res) => {
    try {
        const connection = await connectionMethod.getConnection();
        // execute will internally call prepare and query
        const user1 = await models.User.find({ "username": filter.username });
        // end connection
        // await connectionMethod.closeConnection();
        return user1;
    } catch (error) {
        throw error
    }
};
const getAllUserNameList = async (userIdList, res) => {
    try {
        const connection = await connectionMethod.getConnection();
        // execute will internally call prepare and query
        const users = await models.User.find({ _id: { $in: userIdList } }, { "profile.firstName": 1, "profile.lastName": 1 });
        // end connection
        // await connectionMethod.closeConnection();
        return users;
    } catch (error) {
        throw error
    }
};

// being used in csa
const getUser = async (pageNo, filter, res) => {

    console.log(pageNo)

    try {
        const connection = await connectionMethod.getConnection();


        const page = parseInt(pageNo)
        const limit = 13;
        const skip = parseInt((page - 1) * limit);
        const data = await models.User.find(filter).skip(skip).limit(limit).lean();
        console.log(data)
        // return res.json(data);
        // return data;

        // const user = await models.User.find(filter);

        // end connection
        // await connectionMethod.closeConnection();
        return data;
    } catch (error) {
        throw error
    }
};
const signout = async (username, res) => {
    try {
        // create token
        const token = jwt.sign({ id: username }, "logout", {
            expiresIn: 10 // 1 hour
        });

        const response = {
            accessToken: token,
        };
        successHandler.successHandler(200, 'Successfully logged out.', res, response)
    } catch (error) {
        errorHandler.errorHandler(500, 'Server error occurred', res)
    }

};

const getUserById = async (id, res) => {

    try {
        // const projection = {
        //     _id: 1,
        //     firstName: 1,
        //     lastName: 1,
        //     username: 1,
        //     email: 1,
        //     verified: 1,
        //     admin: 0,
        //     roles: 1,
        // }
        const connection = await connectionMethod.getConnection();
        // execute will internally call prepare and query
        const user = await models.User.findOne({ _id: id });
        console.log(user, 'user')
        // end connection
        // await connectionMethod.closeConnection();
        return user;
    } catch (error) {
        throw error
    }
};


const getAthletes = async (filter, roles, res) => {
    try {
        let filterObject = { roles: { $in: roles } }
        const projection = {
            _id: 1,
            firstName: 1,
            lastName: 1,
            username: 1,
            email: 1,
            verified: 1,
            admin: 0,
            roles: 1,
        }

        // build filter object for query
        if (filter.athletename && filter.athletename != "") {
            filterObject.firstName = new RegExp(filter.athletename, "i")
        }
        if (filter.contactEmail && filter.contactEmail != "") {
            filterObject.email = new RegExp(filter.contactEmail, "i")
        }
        // if (filter.contactNumber && filter.contactNumber != "") {
        //     filterObject.phoneNumber = new RegExp(filter.contactNumber, "i")
        // }
        const connection = await connectionMethod.getConnection();
        // execute will internally call prepare and query
        const athletes = await models.User.find(filterObject, projection);
        // end connection
        // await connectionMethod.closeConnection();
        return athletes;
    } catch (error) {
        console.log(error, 'error')
        throw error
    }
};

const getCoaches = async (filter, role, res) => {
    try {
        let filterObject = { roles: { $in: roles } }
        const projection = {
            _id: 1,
            firstName: 1,
            lastName: 1,
            username: 1,
            email: 1,
            verified: 1,
            admin: 0,
            roles: 1,
        }
        // build filter object for query
        if (filter.coachname && filter.coachname != "") {
            filterObject.firstName = new RegExp(filter.coachname, "i")
        }
        if (filter.contactEmail && filter.contactEmail != "") {
            filterObject.email = new RegExp(filter.contactEmail, "i")
        }
        // if (filter.contactNumber && filter.contactNumber != "") {
        //     filterObject.phoneNumber = new RegExp(filter.contactNumber, "i")
        // }
        const connection = await connectionMethod.getConnection();
        // execute will internally call prepare and query
        const coahes = await models.User.find(filterObject, projection);
        // end connection
        // await connectionMethod.closeConnection();
        return coahes;
    } catch (error) {
        console.log(error, 'eroor')
        throw error
    }
};

// const getAllUsers = async (roles, res, filter) => {
//     try {
//         const connection = await connectionMethod.getConnection();
//         let variables = [];
//         // execute will internally call prepare and query
//         let query = `SELECT id, email_id, first_name,last_name,contact_number,address,district_name,state_name,pincode,role_name,verified FROM ${tableName}`;
//         if (roles && roles != '') {
//             query += ' WHERE role_name = ?';
//             variables.push(roles);
//         }
//         if (stateName && stateName != '') {
//             query += ' AND state_name = ?';
//             variables.push(stateName);
//         }
//         if (filter && filter.district && filter.district != '') {
//             query += ' AND district_name = ?';
//             variables.push(filter.district);
//         }
//         const sql = connection.format(query, variables);
//         const [rows] = await connection.query(sql);
//         // end connection
//         connectionMethod.closeConnection();
//         return rows;
//     } catch (error) {
//         throw error
//     }
// };

// // being used in csa
const updateUser = async (userId, updateData, res) => {
    try {
        const connection = await connectionMethod.getConnection();
        // execute will internally call prepare and query
        const updated = await models.User.findOneAndUpdate({ _id: userId }, updateData);
        console.log(updated, "updated")
        // end connection
        connectionMethod.closeConnection();
        return updated;
    } catch (error) {
        console.log(error, 'error')
        throw error
    }
};
const uploadUserFile = async (uploadData, res) => {

    try {
        const connection = await connectionMethod.getConnection();
        // execute will internally call prepare and query
        const uploaded = await models.User.findOneAndUpdate({ _id: userId }, uploadData);

        console.log(uploaded, "Uploaded Successfully")
        // end connection
        connectionMethod.closeConnection();
        return uploaded;

        // if(file){
        //     uploaded.avatar =file.path
        // }
        // console.log(uploaded.avatar  + "Hello")
        // const saved = await uploaded.avatar.save()

        // if (!saved) {
        //     errorHandler.errorHandler(500, 'Error in adding user to the organisation.', res)
        //     return
        // }
        // // end connection
        // connectionMethod.closeConnection();
        // return saved;
    } catch (error) {
        console.log(error, 'error')
        throw error
    }
};
const getRefreshToken = async (username, userDetails, res) => {
    try {
        // create token
        const token = jwt.sign({ id: username }, authKey, {
            expiresIn: 3600 // 1 hour
        });

        let response = {
            userId: `${userDetails.profile._id}`,
            username: userDetails.username,
            fullName: `${userDetails.profile.firstName} ${userDetails.profile.lastName}`,
            role: userDetails.roles,
            admin: userDetails.profile.admin,
            verified: userDetails.profile.verified,
            accessToken: token,
            // passwordReset: userDetails.passwordReset
        };
        successHandler.successHandler(200, 'Successfully refreshed token.', res, response)
    } catch (error) {
        throw error
    }
};
const insertUserList = async (payloadData, res) => {

    try {
        // Plan  created date
        payloadData._id = new Date().getTime()

        const connection = await connectionMethod.getConnection();
        let newUser = new models.User(payloadData);

        const saved = await newUser.save()
        if (!saved) {
            errorHandler.errorHandler(500, 'Error in adding new  user ', res)
            return
        }
        // set plan id
        payloadData._id = saved._id
        // end connection
        connectionMethod.closeConnection();
        return payloadData
    } catch (error) {
        console.log(error)
        throw error
    }
};
const deleteUserId = async (id, res) => {

    try {
        // const projection = {
        //     _id: 1,
        //     firstName: 1,
        //     lastName: 1,
        //     username: 1,
        //     email: 1,
        //     verified: 1,
        //     admin: 0,
        //     roles: 1,
        // }
        const connection = await connectionMethod.getConnection();
        // execute will internally call prepare and query
        const user = await models.User.deleteOne({ _id: id });
        console.log(user, 'user')
        // end connection
        // await connectionMethod.closeConnection();
        return user;
    } catch (error) {
        throw error
    }
};





const userModel = {
    insertUserList,
    getUserByUsername,
    getUserByName,
    getUserById,
    uploadUserFile,
    updateUser,
    getCoaches,
    getAthletes,
    getUser,
    signout,
    getRefreshToken,
    getCoachesByCoachname,
    getAthletesByAthletename,
    getAgentsByAgentname,
    getCoachesNameList,
    getAthleteNameList,
    getAllUserNameList,
    deleteUserId



};

module.exports = userModel;

