
const models = require(".");
const connectionMethod = require("../../config/db.connection");
const config = require('../../config');



const updateUser = async (paymentId, updateData, res) => {
    try {
        const connection = await connectionMethod.getConnection();
        // execute will internally call prepare and query
        const updated = await models.contact.findOneAndUpdate({ _id: paymentId }, updateData);
        console.log(updated, "updated")
        // end connection
        connectionMethod.closeConnection();
        return updated;
    } catch (error) {
        console.log(error, 'error')
        throw error
    }
};
const getContactDatasByUserId = async (id, res) => {

    try {
        // const projection = {
        //     _id: 1,
        //     firstName: 1,
        //     lastName: 1,
        //     username: 1,
        //     email: 1,
        //     verified: 1,
        //     admin: 0,
        //     roles: 1,
        // }
        const connection = await connectionMethod.getConnection();
        // execute will internally call prepare and query
        const user = await models.contact.findOne({ _id: id });
        console.log(user, 'user')
        // end connection
        // await connectionMethod.closeConnection();
        return user;
    } catch (error) {
        throw error
    }
};




const contactModel = {
    // updateUser,
    getContactDatasByUserId

};

module.exports = contactModel;

