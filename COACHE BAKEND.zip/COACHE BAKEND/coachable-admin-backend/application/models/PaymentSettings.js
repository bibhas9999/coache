const mongoose = require('mongoose')
const mongooseSchema = mongoose.Schema
const paymentSchema = new mongooseSchema({

    _id: { type: String },
    applicationFeePercentage: {
        type: Number,
        default: ''
    },
    firstTierReferrerPercentage: {
        type:Number,
        default: ''
    },
    secondTierReferrerPercentage:{
        type: Number,
        default: ''
    },
    thirdTierReferrerPercentage:{
        type: Number,
        default: ''
    },
    userRole:{
            type: String,
            default: ''
    },
   

});
const payment = mongoose.model('paymentSettings', paymentSchema);
module.exports = payment

