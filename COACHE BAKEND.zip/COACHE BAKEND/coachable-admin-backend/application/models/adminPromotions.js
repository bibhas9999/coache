const mongoose = require('mongoose')
const mongooseSchema = mongoose.Schema
const adminPromotionSchema = new mongooseSchema({

    _id: { type: String },
    // userplanId: {
    //     type: mongoose.Schema.Types.ObjectId,
    //     required: true
    // },
    starts_at: {
        type: String,
        default: ''
    },
    starts_at_timestamp: {
        type: Number,
        default: ''
    },
    expires_at_timestamp: {
        type: Number,
        default: ''
    },
    usage_limit: {
        type: Number,
        default: ''
    },
    duration: {
        type: String,
        default: '',
    },
    limit_used: {
        type: Number,
        default: '',
        trim: true
    },
    duration_in_months: {
        type: Number,
        default: ''
    },
    flat_credits: {
        type: Number,
        default: ''
    },
    discount_percent: {
        type: Number,
        default: ''
    },
    flat_discount: {
        type: Number,
        default: ''
    },
    service_types: {
        type: Array,
        default: ''
    },
    name: {
        type: String,
        default: '',
        trim: true
    },
    userType: {
        type: String,
        default: '',
        trim: true
    },
    expires_at: {
        type: String,
        default: '',
    },
    coupon_code: {
        type: String,
        default: '',
        trim: true
    },
    description: {
        type: String,
        default: '',
        trim: true
    },
    couponId: {
        type: String,
        default: '',
        trim: true
    },
});
const AdminPromotion = mongoose.model('adminpromotions', adminPromotionSchema);
module.exports = AdminPromotion

