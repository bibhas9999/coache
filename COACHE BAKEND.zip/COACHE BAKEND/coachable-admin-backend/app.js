const express = require('express');
//Import the express dependency
//Instantiate an express app, the main work horse of this server
const stripe = require('stripe')('sk_test_51MbiWySANsrydlEod6KGixSbmyGXgfGMUd3wf8SAON3ZUR7jhVPRK1J9EIG7tfwO01KYLz0W8UYAdwY5u8YWaKTp009tSJjgeN');

const app = express();
const bodyParser = require("body-parser");
const cors = require("cors");
// const upload = require("express-fileupload");


const config = require('./config.js');
const PORT = config.get('port');



// commented for future use
const corsOptions = {
    origin: "*"
};
process.env.TZ = "Asia/Kolkata";
app.use(cors(corsOptions));

// parse requests of content-type - application/json
app.use(express.json());
const multer = require('multer');

const csv = require('csv-parser');
const fs = require('fs');
const nodemailer = require('nodemailer');
const router = express.Router();




// parse requests of content-type - application/x-www-form-urlencoded
app.use(express.urlencoded({ extended: false }));

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use('/upload', express.static('upload'))
app.use('/uploads', express.static('uploads'))

// using upload middlewaref
// app.use(upload());

app.use(express.static('public'));

//routes
require('./application/routes')(app);



// simple route
app.get("/", (req, res) => {
    res.json({ message: "Welcome To Coachable Portal" });
});
// set port, listen for requests
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}.`);
}); 