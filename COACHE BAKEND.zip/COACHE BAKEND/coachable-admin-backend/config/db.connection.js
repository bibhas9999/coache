const config = require('../config.js');
// get the client
const mongoose = require('mongoose');
const IP = config.get('ip')
const PORT = config.get('db.port');
const HOST = config.get('db.host');
const DATABASE = config.get('db.name');
const USERNAME = config.get('db.user');
const PASSWORD = config.get('db.password');
const MONGODB_URI = "mongodb://" + HOST + ":" + PORT + "/" + DATABASE;
// db connection code

// satsang db creds
const getConnection = async () => {
	
	// handle error condition here
console.log(`${MONGODB_URI}`);
	const connection = await mongoose.connect(MONGODB_URI, { useNewUrlParser: true })
	return connection
	
}

// close connection
const closeConnection = async () => {
	const closed = await mongoose.connection.close();
	return closed;
}

const connectionMethod = {
	getConnection,
	closeConnection
};

module.exports = connectionMethod;
